"""
Survey Data Analysis Tool
Feature Engineering

Purpose:
    Create machine-learning-friendly features from the cleaned survey data.

Input:
    data/processed/Cleaned_Data.xlsx

Output:
    data/processed/Feature_Engineered_Data.xlsx
    outputs/04_Feature_Engineering/Feature_Engineering_Summary.xlsx
    outputs/04_Feature_Engineering/Feature_Engineering_Summary.txt

Important:
    The original cleaned dataset is NOT modified.
    New engineered features are added to a separate dataset.

Target:
    Social_Media_Usage_Level

        Low      -> Less than 1 hour, 1–2 hours
        Moderate -> 2–3 hours, 3–5 hours
        Heavy    -> More than 5 hours

The target is derived from the respondent's reported daily social-media
usage category. The original daily-usage field is retained for transparency,
but later ML feature selection should avoid using the same target-defining
field to prevent target leakage.
"""

import os
import pandas as pd
import numpy as np


# ============================================================
# 1. DEFINE INPUT AND OUTPUT PATHS
# ============================================================

INPUT_FILE = r"data\processed\Cleaned_Data.xlsx"

OUTPUT_DIR = r"outputs\04_Feature_Engineering"

OUTPUT_FILE = r"data\processed\Feature_Engineered_Data.xlsx"

SUMMARY_EXCEL = os.path.join(
    OUTPUT_DIR,
    "Feature_Engineering_Summary.xlsx"
)

SUMMARY_TXT = os.path.join(
    OUTPUT_DIR,
    "Feature_Engineering_Summary.txt"
)


# Create output folder if it does not already exist
os.makedirs(OUTPUT_DIR, exist_ok=True)


# ============================================================
# 2. LOAD CLEANED DATA
# ============================================================

print("=" * 70)
print("SURVEY DATA ANALYSIS TOOL - FEATURE ENGINEERING")
print("=" * 70)

print("\nLoading cleaned dataset...")

df = pd.read_excel(INPUT_FILE)

print(f"Rows    : {df.shape[0]}")
print(f"Columns : {df.shape[1]}")

# Keep a separate copy.
# The original cleaned dataset will NOT be modified.
feature_df = df.copy()


# ============================================================
# 3. HELPER FUNCTION FOR ORDERED CATEGORICAL SCORES
# ============================================================

def map_ordered_score(series, mapping):
    """
    Convert ordered survey responses into numerical scores.

    Example:
        Never      -> 0
        Rarely     -> 1
        Sometimes  -> 2
        Often      -> 3
        Always     -> 4

    Unknown values are converted to NaN.
    """

    cleaned = (
        series
        .astype("string")
        .str.strip()
        .str.lower()
    )

    return cleaned.map(mapping)


# ============================================================
# 4. CONVERT AGE TO NUMERIC
# ============================================================

if "Age" in feature_df.columns:

    feature_df["Age"] = pd.to_numeric(
        feature_df["Age"],
        errors="coerce"
    )

    print("\nAge converted to numeric format.")


# ============================================================
# 5. CREATE NUMERICAL SURVEY SCORE FEATURES
# ============================================================

print("\nCreating numerical survey scores...")


# ------------------------------------------------------------
# 5.1 Check Frequency Score
# ------------------------------------------------------------

if "Check_Frequency" in feature_df.columns:

    check_frequency_mapping = {
        "never": 0,
        "rarely": 1,
        "sometimes": 2,
        "often": 3,
        "frequently": 4,
        "always": 4
    }

    feature_df["Check_Frequency_Score"] = map_ordered_score(
        feature_df["Check_Frequency"],
        check_frequency_mapping
    )


# ------------------------------------------------------------
# 5.2 Study Distraction Score
# ------------------------------------------------------------

if "Study_Distraction" in feature_df.columns:

    distraction_mapping = {
        "never": 0,
        "rarely": 1,
        "sometimes": 2,
        "often": 3,
        "always": 4
    }

    feature_df["Study_Distraction_Score"] = map_ordered_score(
        feature_df["Study_Distraction"],
        distraction_mapping
    )


# ------------------------------------------------------------
# 5.3 Sleep Quality Score
# ------------------------------------------------------------

if "Sleep_Quality" in feature_df.columns:

    sleep_quality_mapping = {
        "very poor": 0,
        "poor": 1,
        "average": 2,
        "good": 3,
        "very good": 4
    }

    feature_df["Sleep_Quality_Score"] = map_ordered_score(
        feature_df["Sleep_Quality"],
        sleep_quality_mapping
    )


# ------------------------------------------------------------
# 5.4 Stress Score
# ------------------------------------------------------------

if "Social_Media_Stress" in feature_df.columns:

    stress_mapping = {
        "never": 0,
        "rarely": 1,
        "sometimes": 2,
        "often": 3,
        "always": 4
    }

    feature_df["Stress_Score"] = map_ordered_score(
        feature_df["Social_Media_Stress"],
        stress_mapping
    )


# ------------------------------------------------------------
# 5.5 Negative Mood Score
# ------------------------------------------------------------

if "Negative_Mood_Effect" in feature_df.columns:

    mood_mapping = {
        "never": 0,
        "rarely": 1,
        "sometimes": 2,
        "often": 3,
        "always": 4
    }

    feature_df["Negative_Mood_Score"] = map_ordered_score(
        feature_df["Negative_Mood_Effect"],
        mood_mapping
    )


# ------------------------------------------------------------
# 5.6 Social Comparison Score
# ------------------------------------------------------------

if "Social_Comparison" in feature_df.columns:

    comparison_mapping = {
        "never": 0,
        "rarely": 1,
        "sometimes": 2,
        "often": 3,
        "always": 4
    }

    feature_df["Social_Comparison_Score"] = map_ordered_score(
        feature_df["Social_Comparison"],
        comparison_mapping
    )


# ------------------------------------------------------------
# 5.7 Discomfort Without Social Media Score
# ------------------------------------------------------------

if "Discomfort_Without_Access" in feature_df.columns:

    discomfort_mapping = {
        "never": 0,
        "rarely": 1,
        "sometimes": 2,
        "often": 3,
        "always": 4
    }

    feature_df["Access_Discomfort_Score"] = map_ordered_score(
        feature_df["Discomfort_Without_Access"],
        discomfort_mapping
    )


# ------------------------------------------------------------
# 5.8 Desire to Reduce Usage Score
# ------------------------------------------------------------

if "Want_To_Reduce_Usage" in feature_df.columns:

    reduce_mapping = {
        "never": 0,
        "rarely": 1,
        "sometimes": 2,
        "often": 3,
        "always": 4
    }

    feature_df["Reduce_Usage_Score"] = map_ordered_score(
        feature_df["Want_To_Reduce_Usage"],
        reduce_mapping
    )


# ------------------------------------------------------------
# 5.9 Morning Phone Check Score
# ------------------------------------------------------------

if "Morning_Phone_Check" in feature_df.columns:

    morning_mapping = {
        "never": 0,
        "rarely": 1,
        "sometimes": 2,
        "often": 3,
        "always": 4
    }

    feature_df["Morning_Check_Score"] = map_ordered_score(
        feature_df["Morning_Phone_Check"],
        morning_mapping
    )


# ------------------------------------------------------------
# 5.10 Meal-Time Checking Score
# ------------------------------------------------------------

if "Meal_Time_Check" in feature_df.columns:

    meal_mapping = {
        "never": 0,
        "rarely": 1,
        "sometimes": 2,
        "often": 3,
        "always": 4
    }

    feature_df["Meal_Check_Score"] = map_ordered_score(
        feature_df["Meal_Time_Check"],
        meal_mapping
    )


# ------------------------------------------------------------
# 5.11 Extended Scrolling Score
# ------------------------------------------------------------

if "Extended_Scrolling" in feature_df.columns:

    scrolling_mapping = {
        "never": 0,
        "rarely": 1,
        "sometimes": 2,
        "often": 3,
        "always": 4
    }

    feature_df["Extended_Scrolling_Score"] = map_ordered_score(
        feature_df["Extended_Scrolling"],
        scrolling_mapping
    )


# ============================================================
# 6. CONVERT DAILY APP CHECK RANGE TO NUMERIC
# ============================================================

print("\nCreating numeric app-check feature...")


def convert_app_checks(value):
    """
    Convert survey ranges into representative numeric values.

    Examples:
        1-10          -> 5.5
        11-20         -> 15.5
        21-50         -> 35.5
        51-100        -> 75.5
        More than 100 -> 125

    This is an approximate numerical representation of the
    categorical range, not an exact measurement.
    """

    if pd.isna(value):
        return np.nan

    text = str(value).strip().lower()

    if "1-10" in text:
        return 5.5

    if "11-20" in text:
        return 15.5

    if "21-50" in text:
        return 35.5

    if "51-100" in text:
        return 75.5

    if "more than 100" in text:
        return 125.0

    if "100+" in text:
        return 125.0

    return np.nan


if "Daily_App_Checks" in feature_df.columns:

    feature_df["Daily_App_Checks_Numeric"] = (
        feature_df["Daily_App_Checks"]
        .apply(convert_app_checks)
    )


# ============================================================
# 7. CONVERT SLEEP HOURS TO NUMERIC
# ============================================================

print("\nCreating numeric sleep-hours feature...")


def convert_sleep_hours(value):
    """
    Convert sleep-hour categories to approximate numeric values.

    The midpoint of a range is used where appropriate.
    """

    if pd.isna(value):
        return np.nan

    text = str(value).strip().lower()

    if "less than 5" in text:
        return 4.0

    if "5-6" in text:
        return 5.5

    if "6-7" in text:
        return 6.5

    if "7-8" in text:
        return 7.5

    if "more than 8" in text:
        return 9.0

    return np.nan


if "Sleep_Hours" in feature_df.columns:

    feature_df["Sleep_Hours_Numeric"] = (
        feature_df["Sleep_Hours"]
        .apply(convert_sleep_hours)
    )


# ============================================================
# 8. CREATE YES/NO BINARY FEATURES
# ============================================================

print("\nCreating binary behaviour features...")


def yes_no_to_numeric(value):
    """
    Convert Yes/No responses to 1/0.
    """

    if pd.isna(value):
        return np.nan

    text = str(value).strip().lower()

    if text == "yes":
        return 1

    if text == "no":
        return 0

    return np.nan


binary_columns = [
    "Social_Media_While_Studying",
    "Delayed_Study",
    "Social_Media_Before_Sleep",
    "Tried_To_Reduce_Usage"
]


for column in binary_columns:

    if column in feature_df.columns:

        new_column = column + "_Binary"

        feature_df[new_column] = (
            feature_df[column]
            .apply(yes_no_to_numeric)
        )


# ============================================================
# 9. CREATE WELL-BEING SCORE
# ============================================================

print("\nCreating overall well-being score...")


if "Overall_Well_Being" in feature_df.columns:

    wellbeing_mapping = {
        "very poor": 0,
        "poor": 1,
        "fair": 2,
        "average": 2,
        "good": 3,
        "very good": 4,
        "excellent": 5
    }

    feature_df["Well_Being_Score"] = map_ordered_score(
        feature_df["Overall_Well_Being"],
        wellbeing_mapping
    )


# ============================================================
# 10. CREATE SOCIAL MEDIA IMPACT SCORE
# ============================================================

print("\nCreating social media impact score...")


impact_components = [
    "Study_Distraction_Score",
    "Stress_Score",
    "Negative_Mood_Score",
    "Social_Comparison_Score",
    "Access_Discomfort_Score",
    "Reduce_Usage_Score",
    "Extended_Scrolling_Score"
]


available_impact_components = [
    column
    for column in impact_components
    if column in feature_df.columns
]


if available_impact_components:

    feature_df["Social_Media_Impact_Score"] = (
        feature_df[available_impact_components]
        .mean(axis=1)
    )


# ============================================================
# 11. CREATE DIGITAL DEPENDENCY SCORE
# ============================================================

print("\nCreating digital dependency score...")


dependency_components = [
    "Check_Frequency_Score",
    "Daily_App_Checks_Numeric",
    "Morning_Check_Score",
    "Meal_Check_Score",
    "Extended_Scrolling_Score",
    "Access_Discomfort_Score"
]


available_dependency_components = [
    column
    for column in dependency_components
    if column in feature_df.columns
]


if available_dependency_components:

    # App-check count has a larger numerical range than
    # the 0-4 ordinal scores, so normalize it first.
    if "Daily_App_Checks_Numeric" in feature_df.columns:

        max_checks = feature_df["Daily_App_Checks_Numeric"].max()

        if pd.notna(max_checks) and max_checks > 0:

            feature_df["Daily_App_Checks_Normalized"] = (
                feature_df["Daily_App_Checks_Numeric"]
                / max_checks
            )

            dependency_components_for_score = [
                column
                for column in dependency_components
                if column != "Daily_App_Checks_Numeric"
                and column in feature_df.columns
            ]

            dependency_components_for_score.append(
                "Daily_App_Checks_Normalized"
            )

        else:

            dependency_components_for_score = [
                column
                for column in dependency_components
                if column in feature_df.columns
            ]

    else:

        dependency_components_for_score = (
            available_dependency_components
        )

    feature_df["Digital_Dependency_Score"] = (
        feature_df[dependency_components_for_score]
        .mean(axis=1)
    )


# ============================================================
# 12. CREATE TARGET VARIABLE
# ============================================================

print("\nCreating Low / Moderate / Heavy usage target...")


def create_usage_level(value):
    """
    Convert the ACTUAL survey daily social-media usage categories
    into the three required machine-learning classes.

    Actual survey categories:

        Less than 1 hour
        1–2 hours
        2–3 hours
        3–5 hours
        More than 5 hours

    Target definition:

        Low      -> Less than 1 hour, 1–2 hours
        Moderate -> 2–3 hours, 3–5 hours
        Heavy    -> More than 5 hours

    The original Daily_Social_Media_Time column is preserved.
    It will NOT be used as an ML predictor later because it directly
    defines the target and would cause target leakage.
    """

    if pd.isna(value):
        return np.nan

    text = str(value).strip().lower()

    # --------------------------------------------------------
    # LOW
    # --------------------------------------------------------

    if (
        "less than 1 hour" in text
        or "1–2 hours" in text
        or "1-2 hours" in text
    ):
        return "Low"

    # --------------------------------------------------------
    # MODERATE
    # --------------------------------------------------------

    if (
        "2–3 hours" in text
        or "2-3 hours" in text
        or "3–5 hours" in text
        or "3-5 hours" in text
    ):
        return "Moderate"

    # --------------------------------------------------------
    # HEAVY
    # --------------------------------------------------------

    if "more than 5 hours" in text:
        return "Heavy"

    # Any unexpected category is flagged as missing instead
    # of being incorrectly assigned.
    return np.nan


if "Daily_Social_Media_Time" in feature_df.columns:

    feature_df["Social_Media_Usage_Level"] = (
        feature_df["Daily_Social_Media_Time"]
        .apply(create_usage_level)
    )


# ============================================================
# 13. VALIDATE TARGET CREATION
# ============================================================

print("\nValidating target variable...")


if "Social_Media_Usage_Level" in feature_df.columns:

    target_missing = (
        feature_df["Social_Media_Usage_Level"]
        .isna()
        .sum()
    )

    print(
        f"Target values created : "
        f"{feature_df['Social_Media_Usage_Level'].notna().sum()}"
    )

    print(
        f"Target values missing : {target_missing}"
    )

    if target_missing > 0:

        print(
            "\nWARNING: Some survey responses could not be mapped "
            "to a usage level."
        )

    else:

        print(
            "Target validation successful: "
            "all 400 responses were classified."
        )


# ============================================================
# 14. CREATE FEATURE SUMMARY
# ============================================================

print("\nCreating feature summary...")


original_columns = list(df.columns)


new_columns = [
    column
    for column in feature_df.columns
    if column not in original_columns
]


feature_summary_rows = []


for column in new_columns:

    feature_summary_rows.append({
        "Feature_Name": column,
        "Data_Type": str(feature_df[column].dtype),
        "Non_Null_Count": int(
            feature_df[column].notna().sum()
        ),
        "Missing_Count": int(
            feature_df[column].isna().sum()
        ),
        "Description": ""
    })


# ============================================================
# 15. DESCRIPTIONS OF ENGINEERED FEATURES
# ============================================================

descriptions = {

    "Check_Frequency_Score":
        "Ordinal score representing how frequently the student checks social media.",

    "Study_Distraction_Score":
        "Ordinal score representing how frequently social media distracts the student while studying.",

    "Sleep_Quality_Score":
        "Ordinal score representing reported sleep quality.",

    "Stress_Score":
        "Ordinal score representing stress caused by social media use.",

    "Negative_Mood_Score":
        "Ordinal score representing negative mood effects associated with social media.",

    "Social_Comparison_Score":
        "Ordinal score representing frequency of comparing oneself with others on social media.",

    "Access_Discomfort_Score":
        "Ordinal score representing discomfort when social media cannot be accessed.",

    "Reduce_Usage_Score":
        "Ordinal score representing how often the student feels they should reduce social media use.",

    "Morning_Check_Score":
        "Ordinal score representing how frequently the student checks the phone immediately after waking.",

    "Meal_Check_Score":
        "Ordinal score representing how frequently the student checks social media during meals.",

    "Extended_Scrolling_Score":
        "Ordinal score representing frequency of scrolling longer than originally planned.",

    "Daily_App_Checks_Numeric":
        "Approximate numerical representation of the reported daily app-check range.",

    "Daily_App_Checks_Normalized":
        "Normalized daily app-check value used when calculating the dependency score.",

    "Sleep_Hours_Numeric":
        "Approximate numerical representation of reported daily sleep duration.",

    "Well_Being_Score":
        "Ordinal score representing overall well-being.",

    "Social_Media_Impact_Score":
        "Average of selected social-media impact and behavioural scores.",

    "Digital_Dependency_Score":
        "Composite score representing repeated checking and dependency-related behaviour.",

    "Social_Media_While_Studying_Binary":
        "Binary indicator: 1 = Yes, 0 = No.",

    "Delayed_Study_Binary":
        "Binary indicator: 1 = Yes, 0 = No.",

    "Social_Media_Before_Sleep_Binary":
        "Binary indicator: 1 = Yes, 0 = No.",

    "Tried_To_Reduce_Usage_Binary":
        "Binary indicator: 1 = Yes, 0 = No.",

    "Social_Media_Usage_Level":
        "Three-class target: Low, Moderate, or Heavy based on the actual survey daily-usage categories."
}


for row in feature_summary_rows:

    row["Description"] = descriptions.get(
        row["Feature_Name"],
        "Engineered feature created from survey responses."
    )


feature_summary = pd.DataFrame(
    feature_summary_rows
)


# ============================================================
# 16. TARGET DISTRIBUTION
# ============================================================

if "Social_Media_Usage_Level" in feature_df.columns:

    target_distribution = (
        feature_df["Social_Media_Usage_Level"]
        .value_counts(dropna=False)
        .rename_axis("Usage_Level")
        .reset_index(name="Count")
    )

else:

    target_distribution = pd.DataFrame({
        "Usage_Level": [],
        "Count": []
    })


# ============================================================
# 17. DATASET SUMMARY
# ============================================================

dataset_summary = pd.DataFrame({

    "Metric": [
        "Original Rows",
        "Original Columns",
        "Final Rows",
        "Final Columns",
        "New Engineered Features",
        "Missing Values After Engineering",
        "Target Created",
        "Target Missing Values"
    ],

    "Value": [

        df.shape[0],

        df.shape[1],

        feature_df.shape[0],

        feature_df.shape[1],

        len(new_columns),

        int(
            feature_df.isna()
            .sum()
            .sum()
        ),

        (
            "Yes"
            if "Social_Media_Usage_Level"
            in feature_df.columns
            else "No"
        ),

        (
            int(
                feature_df["Social_Media_Usage_Level"]
                .isna()
                .sum()
            )
            if "Social_Media_Usage_Level"
            in feature_df.columns
            else "N/A"
        )
    ]
})


# ============================================================
# 18. SAVE FEATURE-ENGINEERED DATA
# ============================================================

print("\nSaving feature-engineered dataset...")

feature_df.to_excel(
    OUTPUT_FILE,
    index=False
)


# ============================================================
# 19. SAVE EXCEL SUMMARY
# ============================================================

print("Saving feature engineering summary...")

with pd.ExcelWriter(
    SUMMARY_EXCEL,
    engine="openpyxl"
) as writer:

    dataset_summary.to_excel(
        writer,
        sheet_name="Dataset_Summary",
        index=False
    )

    feature_summary.to_excel(
        writer,
        sheet_name="Feature_Summary",
        index=False
    )

    target_distribution.to_excel(
        writer,
        sheet_name="Target_Distribution",
        index=False
    )


# ============================================================
# 20. SAVE TEXT SUMMARY
# ============================================================

summary_text = []


summary_text.append(
    "SURVEY DATA ANALYSIS TOOL - FEATURE ENGINEERING SUMMARY"
)

summary_text.append(
    "=" * 65
)

summary_text.append(
    f"Original rows: {df.shape[0]}"
)

summary_text.append(
    f"Original columns: {df.shape[1]}"
)

summary_text.append(
    f"Final rows: {feature_df.shape[0]}"
)

summary_text.append(
    f"Final columns: {feature_df.shape[1]}"
)

summary_text.append(
    f"New engineered features: {len(new_columns)}"
)

summary_text.append(
    "Total missing values after engineering: "
    f"{int(feature_df.isna().sum().sum())}"
)

summary_text.append("")

summary_text.append(
    "NEW ENGINEERED FEATURES:"
)


for column in new_columns:

    summary_text.append(
        f"- {column}"
    )


summary_text.append("")

summary_text.append(
    "TARGET VARIABLE:"
)

if "Social_Media_Usage_Level" in feature_df.columns:

    summary_text.append(
        "Social_Media_Usage_Level"
    )

    summary_text.append(
        "Low / Moderate / Heavy"
    )

    summary_text.append("")

    summary_text.append(
        "TARGET DEFINITION:"
    )

    summary_text.append(
        "Low = Less than 1 hour OR 1–2 hours"
    )

    summary_text.append(
        "Moderate = 2–3 hours OR 3–5 hours"
    )

    summary_text.append(
        "Heavy = More than 5 hours"
    )

    summary_text.append("")

    summary_text.append(
        "TARGET DISTRIBUTION:"
    )

    for _, row in target_distribution.iterrows():

        summary_text.append(
            f"- {row['Usage_Level']}: {row['Count']}"
        )

else:

    summary_text.append(
        "Target could not be created."
    )


summary_text.append("")

summary_text.append(
    "IMPORTANT:"
)

summary_text.append(
    "The cleaned dataset was NOT modified."
)

summary_text.append(
    "Feature engineering was performed on a separate copy."
)

summary_text.append(
    "The original Daily_Social_Media_Time field was retained "
    "for transparency."
)

summary_text.append(
    "Daily_Social_Media_Time should NOT be used as an ML predictor "
    "because it directly defines the target and would cause target leakage."
)


with open(
    SUMMARY_TXT,
    "w",
    encoding="utf-8"
) as file:

    file.write(
        "\n".join(summary_text)
    )


# ============================================================
# 21. FINAL TERMINAL OUTPUT
# ============================================================

print("\n" + "=" * 70)
print("FEATURE ENGINEERING COMPLETED SUCCESSFULLY")
print("=" * 70)

print("\nOriginal dataset:")
print(f"  Rows    : {df.shape[0]}")
print(f"  Columns : {df.shape[1]}")

print("\nFeature-engineered dataset:")
print(f"  Rows    : {feature_df.shape[0]}")
print(f"  Columns : {feature_df.shape[1]}")

print(
    f"\nNew engineered features: {len(new_columns)}"
)


print("\nTarget distribution:")


if not target_distribution.empty:

    for _, row in target_distribution.iterrows():

        print(
            f"  {row['Usage_Level']}: "
            f"{row['Count']}"
        )


print("\nFeature-engineered dataset saved to:")
print(
    os.path.abspath(OUTPUT_FILE)
)

print("\nFeature engineering summary saved to:")
print(
    os.path.abspath(SUMMARY_EXCEL)
)

print("\nFeature engineering text summary saved to:")
print(
    os.path.abspath(SUMMARY_TXT)
)

print("\nIMPORTANT:")
print(
    "The cleaned dataset was NOT modified."
)
print(
    "Feature engineering outputs were saved separately."
)
print(
    "The feature-engineered dataset will be used "
    "for feature selection."
)