# ================================================================
# SURVEY DATA ANALYSIS TOOL
# STEP 07 - MACHINE LEARNING
# ================================================================
#
# Purpose:
# Train and compare five classification models to classify
# students into:
#     Low
#     Moderate
#     Heavy
# social media usage levels.
#
# Input:
# data/processed/ML_Ready_Data.xlsx
#
# Models:
# 1. Logistic Regression
# 2. Decision Tree
# 3. Random Forest
# 4. K-Nearest Neighbors (KNN)
# 5. Support Vector Machine (SVM)
#
# Evaluation:
# Accuracy
# Precision
# Recall
# F1-Score
# Confusion Matrix
#
# IMPORTANT:
# Daily_Social_Media_Time was already removed during feature
# selection because it directly defines the target variable.
# ================================================================

import os
import warnings
import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder

from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC

from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    classification_report
)

warnings.filterwarnings("ignore")


# ================================================================
# 1. PATHS
# ================================================================

INPUT_FILE = r"data\processed\ML_Ready_Data.xlsx"

OUTPUT_DIR = r"outputs\06_Machine_Learning"

CONFUSION_DIR = os.path.join(
    OUTPUT_DIR,
    "Confusion_Matrices"
)

REPORT_DIR = os.path.join(
    OUTPUT_DIR,
    "Classification_Reports"
)

MODEL_DIR = r"models"


os.makedirs(OUTPUT_DIR, exist_ok=True)
os.makedirs(CONFUSION_DIR, exist_ok=True)
os.makedirs(REPORT_DIR, exist_ok=True)
os.makedirs(MODEL_DIR, exist_ok=True)


# ================================================================
# 2. LOAD DATA
# ================================================================

print("=" * 70)
print("SURVEY DATA ANALYSIS TOOL - MACHINE LEARNING")
print("=" * 70)

print("\nLoading ML-ready dataset...")

df = pd.read_excel(INPUT_FILE)

print(f"Rows    : {df.shape[0]}")
print(f"Columns : {df.shape[1]}")


# ================================================================
# 3. DEFINE TARGET
# ================================================================

TARGET = "Social_Media_Usage_Level"

if TARGET not in df.columns:
    raise ValueError(
        f"Target column '{TARGET}' was not found."
    )

print(f"\nTarget variable: {TARGET}")


# ================================================================
# 4. SEPARATE FEATURES AND TARGET
# ================================================================

X = df.drop(
    columns=[TARGET]
).copy()

y = df[TARGET].astype(str).copy()


print("\nTarget distribution:")

print(
    y.value_counts()
)


# ================================================================
# 5. REMOVE ANY UNEXPECTED LEAKAGE COLUMNS
# ================================================================

leakage_columns = [
    "Daily_Social_Media_Time",
    "Social_Media_Usage_Level",
    "Timestamp"
]

removed_columns = []

for column in leakage_columns:

    if column in X.columns:

        X = X.drop(columns=[column])

        removed_columns.append(column)


if removed_columns:

    print("\nAdditional leakage/non-predictive columns removed:")

    for column in removed_columns:

        print(f"  - {column}")


# ================================================================
# 6. IDENTIFY COLUMN TYPES
# ================================================================

numeric_features = X.select_dtypes(
    include=["int64", "int32", "float64", "float32"]
).columns.tolist()

categorical_features = X.select_dtypes(
    include=["object", "string", "category"]
).columns.tolist()


print("\nFeature types:")

print(
    f"Numerical features   : {len(numeric_features)}"
)

print(
    f"Categorical features : {len(categorical_features)}"
)


# ================================================================
# 7. TRAIN-TEST SPLIT
# ================================================================
#
# 80% -> training
# 20% -> testing
#
# stratify=y keeps the Low/Moderate/Heavy proportions similar
# in both training and testing data.
# ================================================================

print("\nCreating train-test split...")

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.20,
    random_state=42,
    stratify=y
)

print(
    f"Training rows : {X_train.shape[0]}"
)

print(
    f"Testing rows  : {X_test.shape[0]}"
)


# ================================================================
# 8. PREPROCESSING PIPELINE
# ================================================================
#
# Numerical features:
# - Fill missing values using median
# - Standardize using StandardScaler
#
# Categorical features:
# - Fill missing values using most frequent value
# - One-hot encode
#
# This prevents data leakage because preprocessing is fitted
# only on the training data inside the pipeline.
# ================================================================

numeric_pipeline = Pipeline(
    steps=[
        (
            "imputer",
            SimpleImputer(strategy="median")
        ),
        (
            "scaler",
            StandardScaler()
        )
    ]
)


categorical_pipeline = Pipeline(
    steps=[
        (
            "imputer",
            SimpleImputer(strategy="most_frequent")
        ),
        (
            "onehot",
            OneHotEncoder(
                handle_unknown="ignore"
            )
        )
    ]
)


preprocessor = ColumnTransformer(
    transformers=[
        (
            "numeric",
            numeric_pipeline,
            numeric_features
        ),
        (
            "categorical",
            categorical_pipeline,
            categorical_features
        )
    ]
)


# ================================================================
# 9. DEFINE FIVE REQUIRED MODELS
# ================================================================

models = {

    "Logistic_Regression": LogisticRegression(
        max_iter=2000,
        random_state=42
    ),

    "Decision_Tree": DecisionTreeClassifier(
        random_state=42,
        max_depth=8
    ),

    "Random_Forest": RandomForestClassifier(
        n_estimators=200,
        random_state=42,
        class_weight="balanced",
        n_jobs=-1
    ),

    "KNN": KNeighborsClassifier(
        n_neighbors=5
    ),

    "SVM": SVC(
        kernel="rbf",
        probability=True,
        random_state=42,
        class_weight="balanced"
    )
}


# ================================================================
# 10. STORAGE FOR RESULTS
# ================================================================

results = []

classification_reports = {}

confusion_matrices = {}

trained_models = {}


# ================================================================
# 11. TRAIN EACH MODEL
# ================================================================

print("\n")
print("=" * 70)
print("TRAINING MACHINE LEARNING MODELS")
print("=" * 70)


for model_name, model in models.items():

    print(f"\nTraining {model_name}...")

    # Create complete pipeline
    pipeline = Pipeline(
        steps=[
            (
                "preprocessor",
                preprocessor
            ),
            (
                "model",
                model
            )
        ]
    )

    # Train model
    pipeline.fit(
        X_train,
        y_train
    )

    # Predict test data
    y_pred = pipeline.predict(
        X_test
    )

    # ------------------------------------------------------------
    # Evaluation metrics
    # ------------------------------------------------------------

    accuracy = accuracy_score(
        y_test,
        y_pred
    )

    precision = precision_score(
        y_test,
        y_pred,
        average="weighted",
        zero_division=0
    )

    recall = recall_score(
        y_test,
        y_pred,
        average="weighted",
        zero_division=0
    )

    f1 = f1_score(
        y_test,
        y_pred,
        average="weighted",
        zero_division=0
    )

    # ------------------------------------------------------------
    # Confusion matrix
    # ------------------------------------------------------------

    cm = confusion_matrix(
        y_test,
        y_pred,
        labels=["Low", "Moderate", "Heavy"]
    )

    confusion_matrices[model_name] = cm

    # ------------------------------------------------------------
    # Classification report
    # ------------------------------------------------------------

    report = classification_report(
        y_test,
        y_pred,
        labels=["Low", "Moderate", "Heavy"],
        zero_division=0
    )

    classification_reports[model_name] = report

    # ------------------------------------------------------------
    # Store model
    # ------------------------------------------------------------

    trained_models[model_name] = pipeline

    # ------------------------------------------------------------
    # Save model
    # ------------------------------------------------------------

    model_filename = os.path.join(
        MODEL_DIR,
        f"{model_name}.pkl"
    )

    joblib.dump(
        pipeline,
        model_filename
    )

    # ------------------------------------------------------------
    # Save results
    # ------------------------------------------------------------

    results.append({
        "Model": model_name,
        "Accuracy": accuracy,
        "Precision": precision,
        "Recall": recall,
        "F1_Score": f1
    })

    print(
        f"Accuracy  : {accuracy:.4f}"
    )

    print(
        f"Precision : {precision:.4f}"
    )

    print(
        f"Recall    : {recall:.4f}"
    )

    print(
        f"F1-Score  : {f1:.4f}"
    )

    print(
        "Model saved successfully."
    )


# ================================================================
# 12. CREATE RESULTS DATAFRAME
# ================================================================

results_df = pd.DataFrame(
    results
)

results_df = results_df.sort_values(
    by="F1_Score",
    ascending=False
).reset_index(drop=True)


# ================================================================
# 13. SAVE MODEL METRICS
# ================================================================

metrics_file = os.path.join(
    OUTPUT_DIR,
    "Model_Metrics.xlsx"
)

print("\nSaving model metrics...")

with pd.ExcelWriter(
    metrics_file,
    engine="openpyxl"
) as writer:

    results_df.to_excel(
        writer,
        sheet_name="Model_Metrics",
        index=False
    )

    pd.DataFrame({
        "Training_Rows": [len(X_train)],
        "Testing_Rows": [len(X_test)],
        "Test_Size": [0.20],
        "Random_State": [42],
        "Target": [TARGET]
    }).to_excel(
        writer,
        sheet_name="Experiment_Setup",
        index=False
    )


# ================================================================
# 14. SAVE CLASSIFICATION REPORTS
# ================================================================

print("Saving classification reports...")

for model_name, report in classification_reports.items():

    report_file = os.path.join(
        REPORT_DIR,
        f"{model_name}_Classification_Report.txt"
    )

    with open(
        report_file,
        "w",
        encoding="utf-8"
    ) as file:

        file.write(
            f"{model_name} - Classification Report\n"
        )

        file.write(
            "=" * 60 + "\n\n"
        )

        file.write(
            report
        )


# ================================================================
# 15. SAVE CONFUSION MATRICES
# ================================================================

print("Saving confusion matrices...")

class_labels = [
    "Low",
    "Moderate",
    "Heavy"
]


for model_name, cm in confusion_matrices.items():

    # Save Excel matrix
    cm_df = pd.DataFrame(
        cm,
        index=class_labels,
        columns=class_labels
    )

    cm_excel_file = os.path.join(
        CONFUSION_DIR,
        f"{model_name}_Confusion_Matrix.xlsx"
    )

    cm_df.to_excel(
        cm_excel_file
    )

    # ------------------------------------------------------------
    # Save visual confusion matrix
    # ------------------------------------------------------------

    plt.figure(
        figsize=(6, 5)
    )

    plt.imshow(
        cm,
        interpolation="nearest"
    )

    plt.title(
        f"{model_name} - Confusion Matrix"
    )

    plt.colorbar()

    plt.xticks(
        range(len(class_labels)),
        class_labels
    )

    plt.yticks(
        range(len(class_labels)),
        class_labels
    )

    plt.xlabel(
        "Predicted Label"
    )

    plt.ylabel(
        "Actual Label"
    )

    # Display numbers inside cells
    for i in range(cm.shape[0]):

        for j in range(cm.shape[1]):

            plt.text(
                j,
                i,
                cm[i, j],
                ha="center",
                va="center"
            )

    plt.tight_layout()

    plot_file = os.path.join(
        CONFUSION_DIR,
        f"{model_name}_Confusion_Matrix.png"
    )

    plt.savefig(
        plot_file,
        dpi=300,
        bbox_inches="tight"
    )

    plt.close()


# ================================================================
# 16. SAVE TEST PREDICTIONS
# ================================================================
#
# This is useful for later analysis and the Streamlit dashboard.
# ================================================================

prediction_df = X_test.copy()

prediction_df["Actual_Usage_Level"] = y_test.values

for model_name, pipeline in trained_models.items():

    prediction_df[
        f"{model_name}_Prediction"
    ] = pipeline.predict(
        X_test
    )


prediction_file = os.path.join(
    OUTPUT_DIR,
    "Test_Set_Predictions.xlsx"
)

prediction_df.to_excel(
    prediction_file,
    index=False
)


# ================================================================
# 17. SELECT BEST MODEL
# ================================================================

best_model_name = results_df.iloc[0]["Model"]

best_f1 = results_df.iloc[0]["F1_Score"]

best_accuracy = results_df.iloc[0]["Accuracy"]


# ================================================================
# 18. SAVE BEST MODEL INFORMATION
# ================================================================

best_model_info = pd.DataFrame({
    "Best_Model": [best_model_name],
    "Accuracy": [best_accuracy],
    "F1_Score": [best_f1],
    "Selection_Criteria": [
        "Highest weighted F1-Score"
    ]
})


best_model_file = os.path.join(
    OUTPUT_DIR,
    "Best_Model.xlsx"
)

best_model_info.to_excel(
    best_model_file,
    index=False
)


# ================================================================
# 19. CREATE TEXT SUMMARY
# ================================================================

summary_file = os.path.join(
    OUTPUT_DIR,
    "Machine_Learning_Summary.txt"
)


with open(
    summary_file,
    "w",
    encoding="utf-8"
) as file:

    file.write(
        "SURVEY DATA ANALYSIS TOOL - MACHINE LEARNING SUMMARY\n"
    )

    file.write(
        "=" * 65 + "\n\n"
    )

    file.write(
        f"Input dataset: {INPUT_FILE}\n"
    )

    file.write(
        f"Total rows: {len(df)}\n"
    )

    file.write(
        f"Training rows: {len(X_train)}\n"
    )

    file.write(
        f"Testing rows: {len(X_test)}\n\n"
    )

    file.write(
        f"Target variable: {TARGET}\n\n"
    )

    file.write(
        "Models evaluated:\n"
    )

    for model_name in models.keys():

        file.write(
            f"  - {model_name}\n"
        )

    file.write("\n")

    file.write(
        "Model performance:\n\n"
    )

    for _, row in results_df.iterrows():

        file.write(
            f"{row['Model']}\n"
        )

        file.write(
            f"  Accuracy  : {row['Accuracy']:.4f}\n"
        )

        file.write(
            f"  Precision : {row['Precision']:.4f}\n"
        )

        file.write(
            f"  Recall    : {row['Recall']:.4f}\n"
        )

        file.write(
            f"  F1-Score  : {row['F1_Score']:.4f}\n\n"
        )

    file.write(
        "Best model:\n"
    )

    file.write(
        f"  {best_model_name}\n"
    )

    file.write(
        f"  Accuracy: {best_accuracy:.4f}\n"
    )

    file.write(
        f"  F1-Score: {best_f1:.4f}\n"
    )


# ================================================================
# 20. FINAL TERMINAL OUTPUT
# ================================================================

print("\n")
print("=" * 70)
print("MACHINE LEARNING COMPLETED SUCCESSFULLY")
print("=" * 70)

print("\nModel comparison:")

print(
    results_df.to_string(
        index=False
    )
)

print("\n")
print(
    f"BEST MODEL: {best_model_name}"
)

print(
    f"Best Accuracy: {best_accuracy:.4f}"
)

print(
    f"Best F1-Score: {best_f1:.4f}"
)

print("\nModel metrics saved to:")
print(
    os.path.abspath(metrics_file)
)

print("\nConfusion matrices saved to:")
print(
    os.path.abspath(CONFUSION_DIR)
)

print("\nClassification reports saved to:")
print(
    os.path.abspath(REPORT_DIR)
)

print("\nTest predictions saved to:")
print(
    os.path.abspath(prediction_file)
)

print("\nBest model information saved to:")
print(
    os.path.abspath(best_model_file)
)

print("\nTrained models saved to:")
print(
    os.path.abspath(MODEL_DIR)
)

print("\nML summary saved to:")
print(
    os.path.abspath(summary_file)
)

print("\nIMPORTANT:")
print("The ML-ready dataset was NOT modified.")
print("All five required classification models were evaluated.")
print("The best model was selected using weighted F1-Score.")
print("=" * 70)