# ============================================================
# SURVEY DATA ANALYSIS TOOL
# EXPLORATORY DATA ANALYSIS (EDA)
# ============================================================
#
# Purpose:
# This script performs exploratory analysis on the cleaned
# student social media survey dataset.
#
# Input:
#     data/processed/Cleaned_Data.xlsx
#
# Outputs:
#     outputs/02_EDA/Excel/
#     outputs/02_EDA/Plots/
#
# The script:
# 1. Loads the cleaned dataset
# 2. Generates descriptive summaries
# 3. Performs univariate analysis
# 4. Performs bivariate analysis
# 5. Creates plots
# 6. Saves results to Excel
#
# IMPORTANT:
# The cleaned dataset is NOT modified.
# ============================================================

import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


# ============================================================
# 1. PROJECT PATHS
# ============================================================

BASE_DIR = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)

INPUT_FILE = os.path.join(
    BASE_DIR,
    "data",
    "processed",
    "Cleaned_Data.xlsx"
)

EDA_DIR = os.path.join(
    BASE_DIR,
    "outputs",
    "02_EDA"
)

EXCEL_DIR = os.path.join(
    EDA_DIR,
    "Excel"
)

PLOTS_DIR = os.path.join(
    EDA_DIR,
    "Plots"
)

os.makedirs(EXCEL_DIR, exist_ok=True)
os.makedirs(PLOTS_DIR, exist_ok=True)


# ============================================================
# 2. DISPLAY PROJECT INFORMATION
# ============================================================

print("=" * 70)
print("SURVEY DATA ANALYSIS TOOL - EXPLORATORY DATA ANALYSIS")
print("=" * 70)


# ============================================================
# 3. LOAD CLEANED DATA
# ============================================================

print("\nLoading cleaned dataset...")

print(
    f"File: {os.path.basename(INPUT_FILE)}"
)

df = pd.read_excel(
    INPUT_FILE
)

print("\nDataset loaded successfully.")

print(
    f"Rows    : {df.shape[0]}"
)

print(
    f"Columns : {df.shape[1]}"
)


# ============================================================
# 4. HELPER FUNCTION FOR CATEGORICAL ANALYSIS
# ============================================================
#
# This function creates a frequency table containing:
# - category
# - count
# - percentage
#
# It is used repeatedly for categorical survey questions.
# ============================================================

def categorical_summary(dataframe, column):

    result = (
        dataframe[column]
        .value_counts(dropna=False)
        .reset_index()
    )

    result.columns = [
        column,
        "Count"
    ]

    result["Percentage"] = (
        result["Count"]
        / len(dataframe)
        * 100
    ).round(2)

    return result


# ============================================================
# 5. CREATE EXCEL OUTPUT
# ============================================================

excel_file = os.path.join(
    EXCEL_DIR,
    "EDA_Analysis.xlsx"
)

writer = pd.ExcelWriter(
    excel_file,
    engine="openpyxl"
)


# ============================================================
# 6. DATASET OVERVIEW
# ============================================================

overview = pd.DataFrame({

    "Metric": [
        "Number of Rows",
        "Number of Columns",
        "Total Missing Values",
        "Total Duplicate Rows"
    ],

    "Value": [
        len(df),
        len(df.columns),
        int(df.isnull().sum().sum()),
        int(df.duplicated().sum())
    ]
})

overview.to_excel(
    writer,
    sheet_name="Dataset_Overview",
    index=False
)


# ============================================================
# 7. NUMERICAL DESCRIPTIVE STATISTICS
# ============================================================
#
# Numeric variables are summarized using:
# count, mean, standard deviation, minimum, quartiles and maximum.
# ============================================================

numeric_columns = df.select_dtypes(
    include=np.number
).columns.tolist()

if numeric_columns:

    numeric_stats = (
        df[numeric_columns]
        .describe()
        .T
        .reset_index()
    )

    numeric_stats.rename(
        columns={
            "index": "Variable"
        },
        inplace=True
    )

    numeric_stats.to_excel(
        writer,
        sheet_name="Numerical_Statistics",
        index=False
    )


# ============================================================
# 8. CATEGORICAL SUMMARY
# ============================================================
#
# Important categorical variables are analyzed individually.
# ============================================================

categorical_columns = [
    "Gender",
    "Year_of_Study",
    "Social_Media_Platforms",
    "Most_Used_Platform",
    "Daily_Social_Media_Time",
    "Check_Frequency",
    "Daily_App_Checks",
    "Main_Usage_Reason",
    "Social_Media_While_Studying",
    "Study_Distraction_Frequency",
    "Delayed_Study",
    "Academic_Performance",
    "Sleep_Duration",
    "Social_Media_Before_Sleep",
    "Sleep_Delay_Frequency",
    "Sleep_Quality",
    "Social_Media_Stress",
    "Negative_Mood_Frequency",
    "Social_Comparison_Frequency",
    "Discomfort_Without_Social_Media",
    "Reduce_Usage_Frequency",
    "Overall_Well_Being",
    "Morning_Phone_Check",
    "Meal_Time_Check",
    "Extended_Scrolling",
    "Tried_To_Reduce_Usage",
    "Usage_Satisfaction"
]

for column in categorical_columns:

    if column in df.columns:

        summary = categorical_summary(
            df,
            column
        )

        # Excel sheet names have a maximum length of 31
        # characters, so the column name is shortened when
        # necessary.

        sheet_name = (
            "Cat_"
            + column[:27]
        )

        summary.to_excel(
            writer,
            sheet_name=sheet_name,
            index=False
        )


# ============================================================
# 9. AGE DISTRIBUTION
# ============================================================

if "Age" in df.columns:

    age_summary = (
        df["Age"]
        .describe()
        .to_frame()
        .reset_index()
    )

    age_summary.columns = [
        "Statistic",
        "Value"
    ]

    age_summary.to_excel(
        writer,
        sheet_name="Age_Statistics",
        index=False
    )

    plt.figure(
        figsize=(8, 5)
    )

    plt.hist(
        df["Age"].dropna(),
        bins=10
    )

    plt.title(
        "Age Distribution"
    )

    plt.xlabel(
        "Age"
    )

    plt.ylabel(
        "Number of Students"
    )

    plt.tight_layout()

    plt.savefig(
        os.path.join(
            PLOTS_DIR,
            "01_Age_Distribution.png"
        ),
        dpi=300
    )

    plt.close()


# ============================================================
# 10. GENDER DISTRIBUTION
# ============================================================

if "Gender" in df.columns:

    gender_summary = categorical_summary(
        df,
        "Gender"
    )

    plt.figure(
        figsize=(8, 5)
    )

    plt.bar(
        gender_summary["Gender"].astype(str),
        gender_summary["Count"]
    )

    plt.title(
        "Gender Distribution"
    )

    plt.xlabel(
        "Gender"
    )

    plt.ylabel(
        "Number of Students"
    )

    plt.xticks(
        rotation=30,
        ha="right"
    )

    plt.tight_layout()

    plt.savefig(
        os.path.join(
            PLOTS_DIR,
            "02_Gender_Distribution.png"
        ),
        dpi=300
    )

    plt.close()


# ============================================================
# 11. MOST USED SOCIAL MEDIA PLATFORM
# ============================================================

if "Most_Used_Platform" in df.columns:

    platform_summary = categorical_summary(
        df,
        "Most_Used_Platform"
    )

    platform_summary.to_excel(
        writer,
        sheet_name="Platform_Usage",
        index=False
    )

    plt.figure(
        figsize=(9, 5)
    )

    plt.bar(
        platform_summary["Most_Used_Platform"].astype(str),
        platform_summary["Count"]
    )

    plt.title(
        "Most Used Social Media Platform"
    )

    plt.xlabel(
        "Platform"
    )

    plt.ylabel(
        "Number of Students"
    )

    plt.xticks(
        rotation=45,
        ha="right"
    )

    plt.tight_layout()

    plt.savefig(
        os.path.join(
            PLOTS_DIR,
            "03_Most_Used_Platform.png"
        ),
        dpi=300
    )

    plt.close()


# ============================================================
# 12. DAILY SOCIAL MEDIA USAGE
# ============================================================

if "Daily_Social_Media_Time" in df.columns:

    usage_summary = categorical_summary(
        df,
        "Daily_Social_Media_Time"
    )

    usage_summary.to_excel(
        writer,
        sheet_name="Daily_Usage",
        index=False
    )

    plt.figure(
        figsize=(10, 5)
    )

    plt.bar(
        usage_summary[
            "Daily_Social_Media_Time"
        ].astype(str),
        usage_summary["Count"]
    )

    plt.title(
        "Daily Social Media Usage"
    )

    plt.xlabel(
        "Daily Usage Category"
    )

    plt.ylabel(
        "Number of Students"
    )

    plt.xticks(
        rotation=45,
        ha="right"
    )

    plt.tight_layout()

    plt.savefig(
        os.path.join(
            PLOTS_DIR,
            "04_Daily_Social_Media_Usage.png"
        ),
        dpi=300
    )

    plt.close()


# ============================================================
# 13. SOCIAL MEDIA CHECK FREQUENCY
# ============================================================

if "Check_Frequency" in df.columns:

    check_summary = categorical_summary(
        df,
        "Check_Frequency"
    )

    check_summary.to_excel(
        writer,
        sheet_name="Check_Frequency",
        index=False
    )

    plt.figure(
        figsize=(8, 5)
    )

    plt.bar(
        check_summary[
            "Check_Frequency"
        ].astype(str),
        check_summary["Count"]
    )

    plt.title(
        "Social Media Checking Frequency"
    )

    plt.xlabel(
        "Checking Frequency"
    )

    plt.ylabel(
        "Number of Students"
    )

    plt.xticks(
        rotation=30,
        ha="right"
    )

    plt.tight_layout()

    plt.savefig(
        os.path.join(
            PLOTS_DIR,
            "05_Checking_Frequency.png"
        ),
        dpi=300
    )

    plt.close()


# ============================================================
# 14. MAIN REASON FOR SOCIAL MEDIA USE
# ============================================================

if "Main_Usage_Reason" in df.columns:

    reason_summary = categorical_summary(
        df,
        "Main_Usage_Reason"
    )

    reason_summary.to_excel(
        writer,
        sheet_name="Usage_Reasons",
        index=False
    )

    plt.figure(
        figsize=(9, 5)
    )

    plt.bar(
        reason_summary[
            "Main_Usage_Reason"
        ].astype(str),
        reason_summary["Count"]
    )

    plt.title(
        "Main Reasons for Social Media Use"
    )

    plt.xlabel(
        "Reason"
    )

    plt.ylabel(
        "Number of Students"
    )

    plt.xticks(
        rotation=45,
        ha="right"
    )

    plt.tight_layout()

    plt.savefig(
        os.path.join(
            PLOTS_DIR,
            "06_Main_Usage_Reasons.png"
        ),
        dpi=300
    )

    plt.close()


# ============================================================
# 15. ACADEMIC PERFORMANCE
# ============================================================

if "Academic_Performance" in df.columns:

    academic_summary = categorical_summary(
        df,
        "Academic_Performance"
    )

    academic_summary.to_excel(
        writer,
        sheet_name="Academic_Performance",
        index=False
    )

    plt.figure(
        figsize=(9, 5)
    )

    plt.bar(
        academic_summary[
            "Academic_Performance"
        ].astype(str),
        academic_summary["Count"]
    )

    plt.title(
        "Academic Performance Distribution"
    )

    plt.xlabel(
        "Academic Performance"
    )

    plt.ylabel(
        "Number of Students"
    )

    plt.xticks(
        rotation=30,
        ha="right"
    )

    plt.tight_layout()

    plt.savefig(
        os.path.join(
            PLOTS_DIR,
            "07_Academic_Performance.png"
        ),
        dpi=300
    )

    plt.close()


# ============================================================
# 16. SLEEP QUALITY
# ============================================================

if "Sleep_Quality" in df.columns:

    sleep_summary = categorical_summary(
        df,
        "Sleep_Quality"
    )

    sleep_summary.to_excel(
        writer,
        sheet_name="Sleep_Quality",
        index=False
    )

    plt.figure(
        figsize=(8, 5)
    )

    plt.bar(
        sleep_summary[
            "Sleep_Quality"
        ].astype(str),
        sleep_summary["Count"]
    )

    plt.title(
        "Sleep Quality Distribution"
    )

    plt.xlabel(
        "Sleep Quality"
    )

    plt.ylabel(
        "Number of Students"
    )

    plt.xticks(
        rotation=30,
        ha="right"
    )

    plt.tight_layout()

    plt.savefig(
        os.path.join(
            PLOTS_DIR,
            "08_Sleep_Quality.png"
        ),
        dpi=300
    )

    plt.close()


# ============================================================
# 17. OVERALL WELL-BEING
# ============================================================

if "Overall_Well_Being" in df.columns:

    wellbeing_summary = categorical_summary(
        df,
        "Overall_Well_Being"
    )

    wellbeing_summary.to_excel(
        writer,
        sheet_name="Well_Being",
        index=False
    )

    plt.figure(
        figsize=(8, 5)
    )

    plt.bar(
        wellbeing_summary[
            "Overall_Well_Being"
        ].astype(str),
        wellbeing_summary["Count"]
    )

    plt.title(
        "Overall Well-Being Distribution"
    )

    plt.xlabel(
        "Overall Well-Being"
    )

    plt.ylabel(
        "Number of Students"
    )

    plt.xticks(
        rotation=30,
        ha="right"
    )

    plt.tight_layout()

    plt.savefig(
        os.path.join(
            PLOTS_DIR,
            "09_Overall_Well_Being.png"
        ),
        dpi=300
    )

    plt.close()


# ============================================================
# 18. SOCIAL MEDIA USE WHILE STUDYING
# ============================================================

if "Social_Media_While_Studying" in df.columns:

    studying_summary = categorical_summary(
        df,
        "Social_Media_While_Studying"
    )

    studying_summary.to_excel(
        writer,
        sheet_name="Study_Usage",
        index=False
    )

    plt.figure(
        figsize=(8, 5)
    )

    plt.bar(
        studying_summary[
            "Social_Media_While_Studying"
        ].astype(str),
        studying_summary["Count"]
    )

    plt.title(
        "Social Media Use While Studying"
    )

    plt.xlabel(
        "Response"
    )

    plt.ylabel(
        "Number of Students"
    )

    plt.xticks(
        rotation=30,
        ha="right"
    )

    plt.tight_layout()

    plt.savefig(
        os.path.join(
            PLOTS_DIR,
            "10_Social_Media_While_Studying.png"
        ),
        dpi=300
    )

    plt.close()


# ============================================================
# 19. STUDY DISTRACTION
# ============================================================

if "Study_Distraction_Frequency" in df.columns:

    distraction_summary = categorical_summary(
        df,
        "Study_Distraction_Frequency"
    )

    distraction_summary.to_excel(
        writer,
        sheet_name="Study_Distraction",
        index=False
    )

    plt.figure(
        figsize=(8, 5)
    )

    plt.bar(
        distraction_summary[
            "Study_Distraction_Frequency"
        ].astype(str),
        distraction_summary["Count"]
    )

    plt.title(
        "Social Media Study Distraction"
    )

    plt.xlabel(
        "Distraction Frequency"
    )

    plt.ylabel(
        "Number of Students"
    )

    plt.xticks(
        rotation=30,
        ha="right"
    )

    plt.tight_layout()

    plt.savefig(
        os.path.join(
            PLOTS_DIR,
            "11_Study_Distraction.png"
        ),
        dpi=300
    )

    plt.close()


# ============================================================
# 20. BIVARIATE ANALYSIS
# ============================================================
#
# These tables compare important social-media variables with
# academic performance and well-being.
# ============================================================


# ------------------------------------------------------------
# 20A. Daily Usage vs Academic Performance
# ------------------------------------------------------------

if (
    "Daily_Social_Media_Time" in df.columns
    and "Academic_Performance" in df.columns
):

    usage_academic = pd.crosstab(
        df["Daily_Social_Media_Time"],
        df["Academic_Performance"]
    )

    usage_academic.to_excel(
        writer,
        sheet_name="Usage_vs_Academic"
    )


# ------------------------------------------------------------
# 20B. Daily Usage vs Sleep Quality
# ------------------------------------------------------------

if (
    "Daily_Social_Media_Time" in df.columns
    and "Sleep_Quality" in df.columns
):

    usage_sleep = pd.crosstab(
        df["Daily_Social_Media_Time"],
        df["Sleep_Quality"]
    )

    usage_sleep.to_excel(
        writer,
        sheet_name="Usage_vs_Sleep"
    )


# ------------------------------------------------------------
# 20C. Daily Usage vs Well-Being
# ------------------------------------------------------------

if (
    "Daily_Social_Media_Time" in df.columns
    and "Overall_Well_Being" in df.columns
):

    usage_wellbeing = pd.crosstab(
        df["Daily_Social_Media_Time"],
        df["Overall_Well_Being"]
    )

    usage_wellbeing.to_excel(
        writer,
        sheet_name="Usage_vs_WellBeing"
    )


# ------------------------------------------------------------
# 20D. Checking Frequency vs Study Distraction
# ------------------------------------------------------------

if (
    "Check_Frequency" in df.columns
    and "Study_Distraction_Frequency" in df.columns
):

    checking_distraction = pd.crosstab(
        df["Check_Frequency"],
        df["Study_Distraction_Frequency"]
    )

    checking_distraction.to_excel(
        writer,
        sheet_name="Checking_vs_Distraction"
    )


# ------------------------------------------------------------
# 20E. Social Media While Studying vs Academic Performance
# ------------------------------------------------------------

if (
    "Social_Media_While_Studying" in df.columns
    and "Academic_Performance" in df.columns
):

    studying_academic = pd.crosstab(
        df["Social_Media_While_Studying"],
        df["Academic_Performance"]
    )

    studying_academic.to_excel(
        writer,
        sheet_name="StudyUsage_vs_Academic"
    )


# ============================================================
# 21. NUMERICAL CORRELATION
# ============================================================
#
# At this stage the survey contains only a small number of
# genuinely numeric variables such as Age.
#
# We calculate correlation only among numeric variables that
# actually exist. Categorical survey responses are NOT blindly
# converted into numbers here.
# ============================================================

if len(numeric_columns) >= 2:

    correlation = df[numeric_columns].corr()

    correlation.to_excel(
        writer,
        sheet_name="Numeric_Correlation"
    )


# ============================================================
# 22. SAVE EXCEL WORKBOOK
# ============================================================

writer.close()


# ============================================================
# 23. CREATE EDA SUMMARY TEXT FILE
# ============================================================

summary_file = os.path.join(
    EDA_DIR,
    "EDA_Summary.txt"
)

with open(
    summary_file,
    "w",
    encoding="utf-8"
) as file:

    file.write(
        "SURVEY DATA ANALYSIS TOOL - EDA SUMMARY\n"
    )

    file.write(
        "=" * 60 + "\n\n"
    )

    file.write(
        f"Rows analysed: {len(df)}\n"
    )

    file.write(
        f"Columns analysed: {len(df.columns)}\n"
    )

    file.write(
        f"Numeric variables: {len(numeric_columns)}\n"
    )

    file.write(
        f"Categorical variables: {len(categorical_columns)}\n"
    )

    file.write(
        "\nEDA categories analysed:\n"
    )

    file.write(
        "- Demographic distribution\n"
    )

    file.write(
        "- Social media platform usage\n"
    )

    file.write(
        "- Daily social media usage\n"
    )

    file.write(
        "- Checking frequency\n"
    )

    file.write(
        "- Usage reasons\n"
    )

    file.write(
        "- Academic performance\n"
    )

    file.write(
        "- Sleep quality\n"
    )

    file.write(
        "- Overall well-being\n"
    )

    file.write(
        "- Social media use while studying\n"
    )

    file.write(
        "- Study distraction\n"
    )

    file.write(
        "- Bivariate relationships\n"
    )


# ============================================================
# 24. FINAL TERMINAL OUTPUT
# ============================================================

print("\n")
print("=" * 70)
print("EDA COMPLETED SUCCESSFULLY")
print("=" * 70)

print("\nExcel analysis saved to:")
print(excel_file)

print("\nPlots saved to:")
print(PLOTS_DIR)

print("\nEDA summary saved to:")
print(summary_file)

print("\nNumber of rows analysed:")
print(len(df))

print("\nNumber of plots generated:")
print(
    len([
        file
        for file in os.listdir(PLOTS_DIR)
        if file.endswith(".png")
    ])
)

print("\nIMPORTANT:")
print("The cleaned dataset was NOT modified.")
print("EDA outputs were saved separately.")
print("These outputs will be used for statistical analysis.")