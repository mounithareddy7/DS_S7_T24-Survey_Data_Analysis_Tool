# ============================================================
# SURVEY DATA ANALYSIS TOOL
# DATA PREPROCESSING
# ============================================================
#
# Purpose:
# This script cleans and prepares the integrated survey data
# for EDA, statistical analysis, feature engineering and ML.
#
# IMPORTANT:
# - Raw datasets are NOT modified.
# - Integrated_Data.xlsx is NOT modified.
# - The cleaned primary survey dataset is saved separately.
# - Kaggle datasets are retained separately for later
#   comparison/contextual analysis.
# ============================================================


import os
import pandas as pd
import numpy as np


# ============================================================
# 1. DEFINE PROJECT PATHS
# ============================================================

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

INPUT_FILE = os.path.join(
    BASE_DIR,
    "data",
    "interim",
    "Integrated_Data.xlsx"
)

PROCESSED_DIR = os.path.join(
    BASE_DIR,
    "data",
    "processed"
)

OUTPUT_DIR = os.path.join(
    BASE_DIR,
    "outputs",
    "01_Preprocessing"
)

os.makedirs(PROCESSED_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)


# ============================================================
# 2. DISPLAY PROJECT INFORMATION
# ============================================================

print("=" * 70)
print("SURVEY DATA ANALYSIS TOOL - DATA PREPROCESSING")
print("=" * 70)


# ============================================================
# 3. LOAD INTEGRATED WORKBOOK
# ============================================================

print("\nLoading integrated workbook...")

print(f"File: {os.path.basename(INPUT_FILE)}")

excel_file = pd.ExcelFile(INPUT_FILE)

print("\nAvailable sheets:")
for sheet in excel_file.sheet_names:
    print(f"  - {sheet}")


# ============================================================
# 4. LOAD PRIMARY SURVEY DATA
# ============================================================
#
# The Google Survey is the primary dataset because it directly
# represents the project's survey questions and target analysis.
#
# The Addiction and Lifestyle datasets remain separate and will
# NOT be merged into the primary survey at this stage.
# ============================================================

df = pd.read_excel(
    INPUT_FILE,
    sheet_name="Survey_Data"
)

print("\nPrimary Survey Dataset:")
print(f"Rows    : {df.shape[0]}")
print(f"Columns : {df.shape[1]}")


# ============================================================
# 5. CREATE PREPROCESSING REPORT VARIABLES
# ============================================================

original_rows = len(df)
original_columns = len(df.columns)

missing_before = int(df.isnull().sum().sum())
duplicates_before = int(df.duplicated().sum())


# ============================================================
# 6. STANDARDIZE COLUMN NAMES
# ============================================================
#
# We keep the original question text available in the source
# workbook, but use clean machine-friendly column names in the
# processed dataset.
#
# This makes later Python coding easier and avoids problems caused
# by long question text and special characters.
# ============================================================

column_mapping = {
    "Timestamp": "Timestamp",
    "Name": "Name",
    "Age": "Age",
    "Gender": "Gender",
    "Current Year of Study": "Year_of_Study",
    "Which social media platforms do you regularly use?":
        "Social_Media_Platforms",
    "Which platform do you use the most?":
        "Most_Used_Platform",
    "Approximately how much time do you spend on social media per day?":
        "Daily_Social_Media_Time",
    "How frequently do you check social media?":
        "Check_Frequency",
    "Approximately how many times do you check social media per day?":
        "Daily_App_Checks",
    "What is your main reason for using social media?":
        "Main_Usage_Reason",
    "Do you use social media while studying?":
        "Social_Media_While_Studying",
    "How often does social media distract you while studying?":
        "Study_Distraction_Frequency",
    "Have you delayed studying or an assignment because of social media?":
        "Delayed_Study",
    "How would you describe your academic performance?":
        "Academic_Performance",
    "How many hours do you sleep on average per night?":
        "Sleep_Duration",
    "Do you use social media within 30 minutes before going to sleep?":
        "Social_Media_Before_Sleep",
    "How often does social media cause you to sleep later than planned?":
        "Sleep_Delay_Frequency",
    "How would you describe your sleep quality?":
        "Sleep_Quality",
    "How often do you feel stressed because of your social media use?":
        "Social_Media_Stress",
    "How often does social media negatively affect your mood?":
        "Negative_Mood_Frequency",
    "How often do you compare yourself with others on social media?":
        "Social_Comparison_Frequency",
    "How often do you feel uncomfortable when you cannot access social media?":
        "Discomfort_Without_Social_Media",
    "How often do you feel that you should reduce your social media use?":
        "Reduce_Usage_Frequency",
    "How would you rate your overall well-being?":
        "Overall_Well_Being",
    "How often do you check your phone immediately after waking up?":
        "Morning_Phone_Check",
    "How often do you check social media during meals?":
        "Meal_Time_Check",
    "How often do you continue scrolling longer than you originally planned?":
        "Extended_Scrolling",
    "Have you tried to reduce your social media usage?":
        "Tried_To_Reduce_Usage",
    "How satisfied are you with your current social media usage habits?":
        "Usage_Satisfaction"
}


# Apply only mappings for columns that actually exist
df.rename(
    columns={
        old: new
        for old, new in column_mapping.items()
        if old in df.columns
    },
    inplace=True
)


print("\nColumn names standardized successfully.")


# ============================================================
# 7. REMOVE PERSONAL IDENTIFIER
# ============================================================
#
# Name is personally identifiable information and is not useful
# for analysis or machine learning.
#
# Therefore it is removed from the processed dataset.
# ============================================================

if "Name" in df.columns:
    df.drop(columns=["Name"], inplace=True)
    print("Removed personal identifier: Name")


# ============================================================
# 8. CLEAN TIMESTAMP
# ============================================================

if "Timestamp" in df.columns:

    df["Timestamp"] = pd.to_datetime(
        df["Timestamp"],
        errors="coerce"
    )

    print("Timestamp converted to datetime format.")


# ============================================================
# 9. CLEAN NUMERICAL AGE COLUMN
# ============================================================

if "Age" in df.columns:

    df["Age"] = pd.to_numeric(
        df["Age"],
        errors="coerce"
    )

    print("Age converted to numeric format.")


# ============================================================
# 10. REMOVE EXACT DUPLICATE RECORDS
# ============================================================

duplicates_removed = int(df.duplicated().sum())

if duplicates_removed > 0:

    df.drop_duplicates(
        inplace=True
    )

print(
    f"Duplicate rows removed: {duplicates_removed}"
)


# ============================================================
# 11. STANDARDIZE TEXT VALUES
# ============================================================
#
# Leading/trailing spaces can create duplicate categories such as:
#
# "Frequently"
# " Frequently "
#
# They are therefore removed from text fields.
# ============================================================

text_columns = df.select_dtypes(
    include=["object", "string"]
).columns

for column in text_columns:

    df[column] = df[column].apply(
        lambda x: x.strip()
        if isinstance(x, str)
        else x
    )


print("Text values standardized.")


# ============================================================
# 12. CHECK MISSING VALUES
# ============================================================
#
# We do NOT blindly replace missing values.
#
# First we inspect the cleaned dataset. If missing values exist,
# an appropriate strategy can be selected based on the variable.
# ============================================================

missing_after_cleaning = df.isnull().sum()

total_missing = int(
    missing_after_cleaning.sum()
)


# ============================================================
# 13. CREATE DATA QUALITY REPORT
# ============================================================

quality_rows = []

for column in df.columns:

    quality_rows.append({

        "Column": column,

        "Data_Type": str(
            df[column].dtype
        ),

        "Total_Rows": len(df),

        "Missing_Values": int(
            df[column].isnull().sum()
        ),

        "Missing_Percentage": round(
            df[column].isnull().mean() * 100,
            2
        ),

        "Unique_Values": int(
            df[column].nunique(dropna=True)
        ),

        "Duplicate_Values": int(
            df[column].duplicated().sum()
        )
    })


quality_report = pd.DataFrame(
    quality_rows
)


# ============================================================
# 14. CREATE PREPROCESSING SUMMARY
# ============================================================

final_rows = len(df)
final_columns = len(df.columns)

summary_data = {

    "Metric": [

        "Original Rows",

        "Original Columns",

        "Final Rows",

        "Final Columns",

        "Duplicate Rows Before Cleaning",

        "Duplicate Rows Removed",

        "Missing Values Before Cleaning",

        "Missing Values After Cleaning",

        "Personal Identifier Removed",

        "Timestamp Converted",

        "Age Converted To Numeric"

    ],

    "Value": [

        original_rows,

        original_columns,

        final_rows,

        final_columns,

        duplicates_before,

        duplicates_removed,

        missing_before,

        total_missing,

        "Yes",

        "Yes",

        "Yes"

    ]
}


summary_df = pd.DataFrame(
    summary_data
)


# ============================================================
# 15. SAVE CLEANED DATA
# ============================================================

cleaned_file = os.path.join(
    PROCESSED_DIR,
    "Cleaned_Data.xlsx"
)

df.to_excel(
    cleaned_file,
    index=False
)


# ============================================================
# 16. SAVE PREPROCESSING REPORT
# ============================================================

report_file = os.path.join(
    OUTPUT_DIR,
    "Data_Quality_Report.xlsx"
)

with pd.ExcelWriter(
    report_file,
    engine="openpyxl"
) as writer:

    summary_df.to_excel(
        writer,
        sheet_name="Preprocessing_Summary",
        index=False
    )

    quality_report.to_excel(
        writer,
        sheet_name="Data_Quality",
        index=False
    )

    missing_report = (
        missing_after_cleaning
        .reset_index()
    )

    missing_report.columns = [
        "Column",
        "Missing_Values"
    ]

    missing_report.to_excel(
        writer,
        sheet_name="Missing_Values",
        index=False
    )


# ============================================================
# 17. CREATE HUMAN-READABLE SUMMARY
# ============================================================

summary_file = os.path.join(
    OUTPUT_DIR,
    "preprocessing_summary.txt"
)

with open(
    summary_file,
    "w",
    encoding="utf-8"
) as file:

    file.write(
        "SURVEY DATA ANALYSIS TOOL - PREPROCESSING SUMMARY\n"
    )

    file.write("=" * 60 + "\n\n")

    file.write(
        f"Original rows: {original_rows}\n"
    )

    file.write(
        f"Original columns: {original_columns}\n"
    )

    file.write(
        f"Final rows: {final_rows}\n"
    )

    file.write(
        f"Final columns: {final_columns}\n"
    )

    file.write(
        f"Duplicate rows removed: {duplicates_removed}\n"
    )

    file.write(
        f"Missing values after cleaning: {total_missing}\n"
    )

    file.write(
        "Name column removed: Yes\n"
    )

    file.write(
        "Timestamp converted to datetime: Yes\n"
    )

    file.write(
        "Age converted to numeric: Yes\n"
    )


# ============================================================
# 18. DISPLAY FINAL PREPROCESSING RESULTS
# ============================================================

print("\n")
print("=" * 70)
print("PREPROCESSING SUMMARY")
print("=" * 70)

print(f"\nOriginal Rows        : {original_rows}")
print(f"Original Columns     : {original_columns}")

print(f"\nFinal Rows           : {final_rows}")
print(f"Final Columns        : {final_columns}")

print(
    f"\nDuplicate Rows Removed: {duplicates_removed}"
)

print(
    f"Missing Values After : {total_missing}"
)

print(
    "\nPersonal Identifier Removed: Yes"
)

print(
    "Timestamp Converted: Yes"
)

print(
    "Age Converted To Numeric: Yes"
)


# ============================================================
# 19. DISPLAY OUTPUT LOCATIONS
# ============================================================

print("\n")
print("=" * 70)
print("DATA PREPROCESSING COMPLETED SUCCESSFULLY")
print("=" * 70)

print("\nCleaned dataset saved to:")

print(cleaned_file)

print("\nData quality report saved to:")

print(report_file)

print("\nPreprocessing summary saved to:")

print(summary_file)

print("\nIMPORTANT:")
print("Raw datasets were NOT modified.")
print("Integrated_Data.xlsx was NOT modified.")
print("The cleaned survey dataset is ready for EDA.")