# ============================================================
# SURVEY DATA ANALYSIS TOOL
# DATA INTEGRATION
# ============================================================
#
# Purpose:
# This script organizes the three source datasets into one
# controlled integration workbook.
#
# IMPORTANT:
# The datasets are NOT blindly concatenated because they have
# different schemas and represent different observations.
#
# The Google Survey is treated as the PRIMARY dataset.
# The two Kaggle datasets are retained as SECONDARY datasets
# for comparative/contextual analysis.
#
# Input:
#   data/raw/google_survey/
#   data/raw/kaggle/
#
# Output:
#   data/interim/Integrated_Data.xlsx
#
# Raw files are NEVER modified.
# ============================================================


import os
import glob
import pandas as pd


# ============================================================
# 1. DEFINE PROJECT PATHS
# ============================================================

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

GOOGLE_SURVEY_DIR = os.path.join(
    PROJECT_ROOT,
    "data",
    "raw",
    "google_survey"
)

KAGGLE_DIR = os.path.join(
    PROJECT_ROOT,
    "data",
    "raw",
    "kaggle"
)

INTERIM_DIR = os.path.join(
    PROJECT_ROOT,
    "data",
    "interim"
)

OUTPUT_FILE = os.path.join(
    INTERIM_DIR,
    "Integrated_Data.xlsx"
)


# ============================================================
# 2. CREATE OUTPUT DIRECTORY
# ============================================================

os.makedirs(
    INTERIM_DIR,
    exist_ok=True
)


# ============================================================
# 3. FIND INPUT FILES
# ============================================================

survey_files = glob.glob(
    os.path.join(
        GOOGLE_SURVEY_DIR,
        "*.xlsx"
    )
)

addiction_files = glob.glob(
    os.path.join(
        KAGGLE_DIR,
        "social_media_addiction.csv"
    )
)

lifestyle_files = glob.glob(
    os.path.join(
        KAGGLE_DIR,
        "student_lifestyle_dataset.csv"
    )
)


# ============================================================
# 4. VALIDATE FILES
# ============================================================

if not survey_files:
    raise FileNotFoundError(
        "Google Survey Excel file was not found in "
        "data/raw/google_survey/"
    )

if not addiction_files:
    raise FileNotFoundError(
        "social_media_addiction.csv was not found in "
        "data/raw/kaggle/"
    )

if not lifestyle_files:
    raise FileNotFoundError(
        "student_lifestyle_dataset.csv was not found in "
        "data/raw/kaggle/"
    )


# ============================================================
# 5. SELECT INPUT FILES
# ============================================================

survey_file = survey_files[0]

addiction_file = addiction_files[0]

lifestyle_file = lifestyle_files[0]


# ============================================================
# 6. LOAD DATASETS
# ============================================================

print("=" * 70)
print("SURVEY DATA ANALYSIS TOOL - DATA INTEGRATION")
print("=" * 70)

print("\nLoading Google Survey dataset...")
print("File:", os.path.basename(survey_file))

survey_df = pd.read_excel(
    survey_file
)


print("\nLoading Social Media Addiction dataset...")
print("File:", os.path.basename(addiction_file))

addiction_df = pd.read_csv(
    addiction_file
)


print("\nLoading Student Lifestyle dataset...")
print("File:", os.path.basename(lifestyle_file))

lifestyle_df = pd.read_csv(
    lifestyle_file
)


# ============================================================
# 7. ADD SOURCE IDENTIFIERS
# ============================================================
#
# These columns clearly identify where each dataset originated.
#
# They are useful later when explaining the integrated data.
# ============================================================

survey_df["Data_Source"] = "Google Survey"

addiction_df["Data_Source"] = "Kaggle - Social Media Addiction"

lifestyle_df["Data_Source"] = "Kaggle - Student Lifestyle"


# ============================================================
# 8. CREATE INTEGRATION SUMMARY
# ============================================================

summary_df = pd.DataFrame({

    "Dataset": [
        "Google Survey",
        "Social Media Addiction",
        "Student Lifestyle"
    ],

    "Source_Type": [
        "Primary Survey",
        "Secondary Kaggle Dataset",
        "Secondary Kaggle Dataset"
    ],

    "Rows": [
        len(survey_df),
        len(addiction_df),
        len(lifestyle_df)
    ],

    "Columns": [
        len(survey_df.columns),
        len(addiction_df.columns),
        len(lifestyle_df.columns)
    ],

    "Purpose": [
        "Primary dataset for student social media behaviour analysis",
        "Reference dataset for social media usage and addiction patterns",
        "Reference dataset for academic and lifestyle relationships"
    ],

    "Used_For_Main_ML": [
        "Yes",
        "No",
        "No"
    ]
})

# ============================================================
# 9. CREATE COLUMN MAPPING SUMMARY
# ============================================================
#
# This sheet documents the important variables available in
# each dataset. It is used to explain how the datasets relate
# to the project without incorrectly merging unrelated rows.
# ============================================================

mapping_data = [

    # ---------------- GOOGLE SURVEY ----------------
    [
        "Google Survey",
        "Daily Social Media Time",
        "Approximately how much time do you spend on social media per day?",
        "Social media usage",
        "Primary analysis"
    ],

    [
        "Google Survey",
        "Social Media Check Frequency",
        "How frequently do you check social media?",
        "Usage frequency",
        "Primary analysis"
    ],

    [
        "Google Survey",
        "Daily App Checks",
        "Approximately how many times do you check social media per day?",
        "Usage behaviour",
        "Primary analysis"
    ],

    [
        "Google Survey",
        "Academic Performance",
        "How would you describe your academic performance?",
        "Academic behaviour",
        "Primary analysis"
    ],

    [
        "Google Survey",
        "Sleep Duration",
        "How many hours do you sleep on average per night?",
        "Sleep behaviour",
        "Primary analysis"
    ],

    [
        "Google Survey",
        "Overall Well-Being",
        "How would you rate your overall well-being?",
        "Well-being",
        "Primary analysis"
    ],

    # ---------------- ADDICTION DATASET ----------------
    [
        "Social Media Addiction",
        "Daily Usage Time",
        "Daily_Usage_Time_min",
        "Social media usage",
        "Secondary comparison"
    ],

    [
        "Social Media Addiction",
        "Addiction Level",
        "Addiction_Level",
        "Addiction behaviour",
        "Secondary comparison"
    ],

    [
        "Social Media Addiction",
        "Mental Health Index",
        "Mental_Health_Index",
        "Mental health",
        "Secondary comparison"
    ],

    [
        "Social Media Addiction",
        "Productivity Loss Score",
        "Productivity_Loss_Score",
        "Productivity",
        "Secondary comparison"
    ],

    [
        "Social Media Addiction",
        "FOMO Score",
        "FOMO_Score",
        "Fear of missing out",
        "Secondary comparison"
    ],

    # ---------------- STUDENT LIFESTYLE DATASET ----------------
    [
        "Student Lifestyle",
        "Study Hours",
        "Study_Hours_Per_Day",
        "Academic behaviour",
        "Secondary context"
    ],

    [
        "Student Lifestyle",
        "Sleep Hours",
        "Sleep_Hours_Per_Day",
        "Sleep behaviour",
        "Secondary context"
    ],

    [
        "Student Lifestyle",
        "Social Hours",
        "Social_Hours_Per_Day",
        "Social activity",
        "Secondary context"
    ],

    [
        "Student Lifestyle",
        "GPA",
        "GPA",
        "Academic performance",
        "Secondary context"
    ],

    [
        "Student Lifestyle",
        "Stress Level",
        "Stress_Level",
        "Student stress",
        "Secondary context"
    ]
]


mapping_df = pd.DataFrame(
    mapping_data,
    columns=[
        "Dataset",
        "Variable",
        "Original_Column",
        "Relevant_Concept",
        "Role"
    ]
)

# ============================================================
# 10. SAVE INTEGRATED WORKBOOK
# ============================================================

with pd.ExcelWriter(
    OUTPUT_FILE,
    engine="openpyxl"
) as writer:

    survey_df.to_excel(
        writer,
        sheet_name="Survey_Data",
        index=False
    )

    addiction_df.to_excel(
        writer,
        sheet_name="Addiction_Data",
        index=False
    )

    lifestyle_df.to_excel(
        writer,
        sheet_name="Lifestyle_Data",
        index=False
    )

    summary_df.to_excel(
        writer,
        sheet_name="Integration_Summary",
        index=False
    )

    mapping_df.to_excel(
        writer,
        sheet_name="Variable_Mapping",
        index=False
    )


# ============================================================
# 11. DISPLAY INTEGRATION SUMMARY
# ============================================================

print("\n")
print("=" * 70)
print("INTEGRATION SUMMARY")
print("=" * 70)

print("\nGoogle Survey:")
print("Rows    :", len(survey_df))
print("Columns :", len(survey_df.columns))

print("\nSocial Media Addiction:")
print("Rows    :", len(addiction_df))
print("Columns :", len(addiction_df.columns))

print("\nStudent Lifestyle:")
print("Rows    :", len(lifestyle_df))
print("Columns :", len(lifestyle_df.columns))


# ============================================================
# 12. DISPLAY OUTPUT INFORMATION
# ============================================================

print("\n")
print("=" * 70)
print("DATA INTEGRATION COMPLETED SUCCESSFULLY")
print("=" * 70)

print("\nIntegrated workbook saved to:")
print(OUTPUT_FILE)

print("\nWorkbook sheets created:")
print("  1. Survey_Data")
print("  2. Addiction_Data")
print("  3. Lifestyle_Data")
print("  4. Integration_Summary")
print("  5. Variable_Mapping")

print("\nIMPORTANT:")
print("The three datasets were NOT blindly concatenated.")
print("The Google Survey remains the primary dataset.")
print("Kaggle datasets are retained for secondary comparison")
print("and contextual analysis.")

print("\nRaw datasets were NOT modified.")