# ============================================================
# SURVEY DATA ANALYSIS TOOL
# DATA INSPECTION
# ============================================================
# Purpose:
# This script performs the first inspection of all raw datasets.
#
# Datasets:
# 1. Google Survey Responses
# 2. Social Media Addiction Dataset
# 3. Student Lifestyle Dataset
#
# The script checks:
# - Number of rows and columns
# - Column names
# - Data types
# - Missing values
# - Duplicate records
# - Unique values
# - Sample records
#
# Output:
# outputs/00_Data_Inspection/Data_Inspection_Report.xlsx
#
# IMPORTANT:
# Raw datasets are only READ.
# They are NOT modified by this script.
# ============================================================


import os
import glob
import pandas as pd


# ============================================================
# 1. DEFINE PROJECT PATHS
# ============================================================

# Project root is the folder containing this script's parent folder.
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

RAW_GOOGLE_PATH = os.path.join(
    PROJECT_ROOT,
    "data",
    "raw",
    "google_survey"
)

RAW_KAGGLE_PATH = os.path.join(
    PROJECT_ROOT,
    "data",
    "raw",
    "kaggle"
)

OUTPUT_FOLDER = os.path.join(
    PROJECT_ROOT,
    "outputs",
    "00_Data_Inspection"
)

# Create output folder if it does not already exist.
os.makedirs(OUTPUT_FOLDER, exist_ok=True)


# ============================================================
# 2. LOCATE THE RAW DATASETS
# ============================================================

# Find the survey Excel file automatically.
survey_files = glob.glob(
    os.path.join(RAW_GOOGLE_PATH, "*.xlsx")
)

# Find the Kaggle CSV files.
kaggle_files = glob.glob(
    os.path.join(RAW_KAGGLE_PATH, "*.csv")
)


# ============================================================
# 3. CHECK WHETHER FILES EXIST
# ============================================================

if len(survey_files) == 0:
    print("ERROR: No Excel survey file found.")
    print(f"Expected location: {RAW_GOOGLE_PATH}")
    raise FileNotFoundError("Survey Excel file not found.")

if len(kaggle_files) == 0:
    print("ERROR: No Kaggle CSV files found.")
    print(f"Expected location: {RAW_KAGGLE_PATH}")
    raise FileNotFoundError("Kaggle CSV files not found.")


print("=" * 70)
print("SURVEY DATA ANALYSIS TOOL - DATA INSPECTION")
print("=" * 70)


# ============================================================
# 4. STORE ALL DATASETS
# ============================================================

datasets = {}


# ------------------------------------------------------------
# 4.1 Load Google Survey Dataset
# ------------------------------------------------------------

survey_path = survey_files[0]

print("\nLoading Google Survey dataset...")
print(f"File: {os.path.basename(survey_path)}")

survey_df = pd.read_excel(survey_path)

datasets["Google Survey"] = survey_df


# ------------------------------------------------------------
# 4.2 Load Kaggle Datasets
# ------------------------------------------------------------

for file_path in kaggle_files:

    file_name = os.path.basename(file_path)

    print(f"\nLoading Kaggle dataset...")
    print(f"File: {file_name}")

    # Read CSV file.
    df = pd.read_csv(file_path)

    # Create a readable dataset name.
    dataset_name = os.path.splitext(file_name)[0]

    datasets[dataset_name] = df


# ============================================================
# 5. CREATE EXCEL REPORT
# ============================================================

output_path = os.path.join(
    OUTPUT_FOLDER,
    "Data_Inspection_Report.xlsx"
)


with pd.ExcelWriter(output_path, engine="openpyxl") as writer:

    # --------------------------------------------------------
    # Overall Dataset Summary
    # --------------------------------------------------------

    overview_records = []

    for dataset_name, df in datasets.items():

        overview_records.append({
            "Dataset": dataset_name,
            "Rows": df.shape[0],
            "Columns": df.shape[1],
            "Duplicate Rows": int(df.duplicated().sum()),
            "Total Missing Values": int(df.isna().sum().sum()),
            "Numeric Columns": len(
                df.select_dtypes(include="number").columns
            ),
            "Text/Categorical Columns": len(
            df.select_dtypes(include=["object", "string"]).columns
            )
        })

    overview_df = pd.DataFrame(overview_records)

    overview_df.to_excel(
        writer,
        sheet_name="Dataset_Overview",
        index=False
    )


    # ========================================================
    # 6. DETAILED INSPECTION FOR EACH DATASET
    # ========================================================

    for dataset_name, df in datasets.items():

        # Create a safe Excel sheet name.
        sheet_prefix = dataset_name[:20]

        # ----------------------------------------------------
        # 6.1 Column Information
        # ----------------------------------------------------

        column_info = pd.DataFrame({
            "Column Name": df.columns,
            "Data Type": [
                str(dtype)
                for dtype in df.dtypes
            ],
            "Missing Values": [
                int(value)
                for value in df.isna().sum()
            ],
            "Missing Percentage": [
                round(value / len(df) * 100, 2)
                if len(df) > 0 else 0
                for value in df.isna().sum()
            ],
            "Unique Values": [
                int(df[column].nunique(dropna=True))
                for column in df.columns
            ]
        })

        column_info.to_excel(
            writer,
            sheet_name=f"{sheet_prefix}_Columns",
            index=False
        )


        # ----------------------------------------------------
        # 6.2 Missing Value Analysis
        # ----------------------------------------------------

        missing_df = pd.DataFrame({
            "Column": df.columns,
            "Missing Count": df.isna().sum().values,
            "Missing Percentage": (
                df.isna().mean().values * 100
            ).round(2)
        })

        missing_df.to_excel(
            writer,
            sheet_name=f"{sheet_prefix}_Missing",
            index=False
        )


        # ----------------------------------------------------
        # 6.3 Duplicate Analysis
        # ----------------------------------------------------

        duplicate_count = int(df.duplicated().sum())

        duplicate_summary = pd.DataFrame({
            "Dataset": [dataset_name],
            "Total Rows": [len(df)],
            "Duplicate Rows": [duplicate_count],
            "Unique Rows": [len(df) - duplicate_count]
        })

        duplicate_summary.to_excel(
            writer,
            sheet_name=f"{sheet_prefix}_Duplicates",
            index=False
        )


        # ----------------------------------------------------
        # 6.4 Sample Records
        # ----------------------------------------------------

        sample_df = df.head(10)

        sample_df.to_excel(
            writer,
            sheet_name=f"{sheet_prefix}_Sample",
            index=False
        )


        # ----------------------------------------------------
        # 6.5 Descriptive Statistics
        # ----------------------------------------------------

        numeric_columns = df.select_dtypes(
            include="number"
        ).columns

        if len(numeric_columns) > 0:

            descriptive_df = df[numeric_columns].describe().T

            descriptive_df.to_excel(
                writer,
                sheet_name=f"{sheet_prefix}_Stats"
            )


# ============================================================
# 7. PRINT RESULTS TO TERMINAL
# ============================================================

print("\n")
print("=" * 70)
print("DATASET INSPECTION SUMMARY")
print("=" * 70)


for dataset_name, df in datasets.items():

    print("\n" + "-" * 70)
    print(f"DATASET: {dataset_name}")
    print("-" * 70)

    print(f"Rows              : {df.shape[0]}")
    print(f"Columns           : {df.shape[1]}")
    print(f"Duplicate Rows    : {df.duplicated().sum()}")
    print(f"Missing Values    : {df.isna().sum().sum()}")

    print("\nColumn Names:")

    for column in df.columns:
        print(f"  - {column}")


# ============================================================
# 8. FINAL MESSAGE
# ============================================================

print("\n")
print("=" * 70)
print("DATA INSPECTION COMPLETED SUCCESSFULLY")
print("=" * 70)

print(f"\nInspection report saved to:")
print(output_path)

print("\nIMPORTANT:")
print("Raw datasets were only read and were NOT modified.")
print("The inspection report will be used to design preprocessing.")