# ============================================================
# SURVEY DATA ANALYSIS TOOL
# STATISTICAL ANALYSIS
# ============================================================
#
# Purpose:
# This script performs statistical analysis on the cleaned
# student social media survey dataset.
#
# Input:
#     data/processed/Cleaned_Data.xlsx
#
# Outputs:
#     outputs/03_Statistical_Analysis/
#
# Analyses performed:
# 1. Descriptive Statistics
# 2. Correlation Analysis
# 3. Covariance Analysis
# 4. Hypothesis Testing
# 5. Chi-Square Tests
#
# IMPORTANT:
# - The cleaned dataset is NOT modified.
# - Categorical survey responses are not blindly converted
#   into numbers.
# - Chi-square is used for categorical relationships.
# - Numeric/ordinal variables are encoded only where
#   statistically appropriate.
# ============================================================


import os
import pandas as pd
import numpy as np

from scipy.stats import (
    chi2_contingency,
    spearmanr,
    pearsonr,
    ttest_ind
)


# ============================================================
# 1. PROJECT PATHS
# ============================================================

BASE_DIR = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)

INPUT_FILE = os.path.join(
    BASE_DIR,
    "data",
    "processed",
    "Cleaned_Data.xlsx"
)

OUTPUT_DIR = os.path.join(
    BASE_DIR,
    "outputs",
    "03_Statistical_Analysis"
)

os.makedirs(
    OUTPUT_DIR,
    exist_ok=True
)


# ============================================================
# 2. DISPLAY HEADER
# ============================================================

print("=" * 70)
print("SURVEY DATA ANALYSIS TOOL - STATISTICAL ANALYSIS")
print("=" * 70)


# ============================================================
# 3. LOAD CLEANED DATA
# ============================================================

print("\nLoading cleaned dataset...")

df = pd.read_excel(
    INPUT_FILE
)

print(
    f"Rows    : {df.shape[0]}"
)

print(
    f"Columns : {df.shape[1]}"
)


# ============================================================
# 4. DESCRIPTIVE STATISTICS
# ============================================================
#
# Numeric variables are summarized using:
# - Count
# - Mean
# - Standard deviation
# - Minimum
# - Quartiles
# - Maximum
#
# For categorical variables, frequency and percentage
# distributions are also generated.
# ============================================================

print("\nCreating descriptive statistics...")


# ------------------------------------------------------------
# 4A. Numerical descriptive statistics
# ------------------------------------------------------------

numeric_columns = df.select_dtypes(
    include=np.number
).columns.tolist()

if numeric_columns:

    descriptive_numeric = (
        df[numeric_columns]
        .describe()
        .T
        .reset_index()
    )

    descriptive_numeric.rename(
        columns={
            "index": "Variable"
        },
        inplace=True
    )

else:

    descriptive_numeric = pd.DataFrame(
        columns=[
            "Variable",
            "count",
            "mean",
            "std",
            "min",
            "25%",
            "50%",
            "75%",
            "max"
        ]
    )


# ------------------------------------------------------------
# 4B. Categorical frequency statistics
# ------------------------------------------------------------

categorical_columns = df.select_dtypes(
    include=["object", "string"]
).columns.tolist()

categorical_frequency = []

for column in categorical_columns:

    counts = (
        df[column]
        .value_counts(dropna=False)
    )

    for category, count in counts.items():

        categorical_frequency.append({

            "Variable": column,

            "Category": category,

            "Count": int(count),

            "Percentage": round(
                count / len(df) * 100,
                2
            )
        })


categorical_frequency_df = pd.DataFrame(
    categorical_frequency
)


# ------------------------------------------------------------
# 4C. Save descriptive statistics
# ------------------------------------------------------------

descriptive_file = os.path.join(
    OUTPUT_DIR,
    "Descriptive_Statistics.xlsx"
)

with pd.ExcelWriter(
    descriptive_file,
    engine="openpyxl"
) as writer:

    descriptive_numeric.to_excel(
        writer,
        sheet_name="Numerical_Statistics",
        index=False
    )

    categorical_frequency_df.to_excel(
        writer,
        sheet_name="Categorical_Frequencies",
        index=False
    )


print(
    "Descriptive statistics completed."
)


# ============================================================
# 5. CREATE ORDINAL ENCODINGS
# ============================================================
#
# Several survey variables have a natural order.
#
# Example:
#
# Never < Rarely < Sometimes < Often < Always
#
# These can be encoded for Spearman correlation because
# Spearman correlation is appropriate for ordinal variables.
#
# IMPORTANT:
# We do NOT use arbitrary numeric encoding for nominal
# variables such as Gender or Platform.
# ============================================================

ordinal_mappings = {

    "Check_Frequency": {
        "Never": 0,
        "Rarely": 1,
        "Sometimes": 2,
        "Frequently": 3,
        "Often": 3,
        "Always": 4
    },

    "Study_Distraction_Frequency": {
        "Never": 0,
        "Rarely": 1,
        "Sometimes": 2,
        "Often": 3,
        "Always": 4
    },

    "Sleep_Delay_Frequency": {
        "Never": 0,
        "Rarely": 1,
        "Sometimes": 2,
        "Often": 3,
        "Always": 4
    },

    "Social_Media_Stress": {
        "Never": 0,
        "Rarely": 1,
        "Sometimes": 2,
        "Often": 3,
        "Always": 4
    },

    "Negative_Mood_Frequency": {
        "Never": 0,
        "Rarely": 1,
        "Sometimes": 2,
        "Often": 3,
        "Always": 4
    },

    "Social_Comparison_Frequency": {
        "Never": 0,
        "Rarely": 1,
        "Sometimes": 2,
        "Often": 3,
        "Always": 4
    },

    "Discomfort_Without_Social_Media": {
        "Never": 0,
        "Rarely": 1,
        "Sometimes": 2,
        "Often": 3,
        "Always": 4
    },

    "Reduce_Usage_Frequency": {
        "Never": 0,
        "Rarely": 1,
        "Sometimes": 2,
        "Often": 3,
        "Always": 4
    },

    "Morning_Phone_Check": {
        "Never": 0,
        "Rarely": 1,
        "Sometimes": 2,
        "Often": 3,
        "Always": 4
    },

    "Meal_Time_Check": {
        "Never": 0,
        "Rarely": 1,
        "Sometimes": 2,
        "Often": 3,
        "Always": 4
    },

    "Extended_Scrolling": {
        "Never": 0,
        "Rarely": 1,
        "Sometimes": 2,
        "Often": 3,
        "Always": 4
    }
}


ordinal_df = pd.DataFrame(
    index=df.index
)

for column, mapping in ordinal_mappings.items():

    if column in df.columns:

        ordinal_df[column] = (
            df[column]
            .map(mapping)
        )


# ============================================================
# 6. CORRELATION ANALYSIS
# ============================================================
#
# Two types are calculated:
#
# 1. Pearson correlation for numerical variables.
# 2. Spearman correlation for ordinal survey variables.
#
# Pearson:
# Measures linear relationship between numerical variables.
#
# Spearman:
# Measures monotonic relationship between ordinal variables.
# ============================================================

print("\nCreating correlation analysis...")


# ------------------------------------------------------------
# 6A. Pearson correlation
# ------------------------------------------------------------

pearson_file = os.path.join(
    OUTPUT_DIR,
    "Correlation.xlsx"
)


if len(numeric_columns) >= 2:

    pearson_correlation = (
        df[numeric_columns]
        .corr(method="pearson")
    )

else:

    pearson_correlation = pd.DataFrame(
        {
            "Information": [
                "Less than two numerical variables were available.",
                "Pearson correlation could not be calculated."
            ]
        }
    )


# ------------------------------------------------------------
# 6B. Spearman correlation
# ------------------------------------------------------------

if len(ordinal_df.columns) >= 2:

    spearman_correlation = (
        ordinal_df
        .corr(method="spearman")
    )

else:

    spearman_correlation = pd.DataFrame(
        {
            "Information": [
                "Less than two ordinal variables were available.",
                "Spearman correlation could not be calculated."
            ]
        }
    )


with pd.ExcelWriter(
    pearson_file,
    engine="openpyxl"
) as writer:

    pearson_correlation.to_excel(
        writer,
        sheet_name="Pearson_Correlation"
    )

    spearman_correlation.to_excel(
        writer,
        sheet_name="Spearman_Correlation"
    )


print(
    "Correlation analysis completed."
)


# ============================================================
# 7. COVARIANCE ANALYSIS
# ============================================================
#
# Covariance is calculated for numerical variables.
#
# Positive covariance:
# Variables tend to increase together.
#
# Negative covariance:
# One variable tends to increase when the other decreases.
#
# Covariance is scale-dependent, so it is interpreted together
# with correlation rather than by itself.
# ============================================================

print("\nCreating covariance analysis...")


if len(numeric_columns) >= 2:

    covariance_matrix = (
        df[numeric_columns]
        .cov()
    )

else:

    covariance_matrix = pd.DataFrame(
        {
            "Information": [
                "Less than two numerical variables were available.",
                "Covariance could not be calculated."
            ]
        }
    )


covariance_file = os.path.join(
    OUTPUT_DIR,
    "Covariance.xlsx"
)

covariance_matrix.to_excel(
    covariance_file
)


print(
    "Covariance analysis completed."
)


# ============================================================
# 8. CHI-SQUARE TESTS
# ============================================================
#
# Chi-square test of independence determines whether two
# categorical variables are statistically associated.
#
# Null hypothesis:
# H0 = The two categorical variables are independent.
#
# Alternative hypothesis:
# H1 = The two categorical variables are associated.
#
# Significance level:
# alpha = 0.05
# ============================================================

print("\nCreating Chi-square analysis...")


chi_square_results = []


def run_chi_square(
    dataframe,
    variable_1,
    variable_2
):

    if (
        variable_1 not in dataframe.columns
        or variable_2 not in dataframe.columns
    ):

        return

    # Remove missing combinations
    temp = dataframe[
        [
            variable_1,
            variable_2
        ]
    ].dropna()

    if temp.empty:
        return

    contingency_table = pd.crosstab(
        temp[variable_1],
        temp[variable_2]
    )

    # Chi-square requires a table with at least
    # two rows and two columns.

    if (
        contingency_table.shape[0] < 2
        or contingency_table.shape[1] < 2
    ):

        return

    chi2, p_value, degrees_of_freedom, expected = (
        chi2_contingency(
            contingency_table
        )
    )

    chi_square_results.append({

        "Variable_1": variable_1,

        "Variable_2": variable_2,

        "Chi_Square": round(
            chi2,
            4
        ),

        "Degrees_of_Freedom": degrees_of_freedom,

        "P_Value": round(
            p_value,
            6
        ),

        "Significance_Level": 0.05,

        "Result": (
            "Significant Association"
            if p_value < 0.05
            else
            "No Significant Association"
        ),

        "Null_Hypothesis": (
            "Variables are independent"
        ),

        "Alternative_Hypothesis": (
            "Variables are associated"
        )
    })


# ------------------------------------------------------------
# Important project relationships
# ------------------------------------------------------------

chi_square_pairs = [

    (
        "Daily_Social_Media_Time",
        "Academic_Performance"
    ),

    (
        "Daily_Social_Media_Time",
        "Sleep_Quality"
    ),

    (
        "Daily_Social_Media_Time",
        "Overall_Well_Being"
    ),

    (
        "Check_Frequency",
        "Study_Distraction_Frequency"
    ),

    (
        "Social_Media_While_Studying",
        "Academic_Performance"
    ),

    (
        "Social_Media_Before_Sleep",
        "Sleep_Quality"
    ),

    (
        "Main_Usage_Reason",
        "Academic_Performance"
    ),

    (
        "Most_Used_Platform",
        "Academic_Performance"
    ),

    (
        "Extended_Scrolling",
        "Overall_Well_Being"
    ),

    (
        "Tried_To_Reduce_Usage",
        "Usage_Satisfaction"
    )
]


for variable_1, variable_2 in chi_square_pairs:

    run_chi_square(
        df,
        variable_1,
        variable_2
    )


chi_square_results_df = pd.DataFrame(
    chi_square_results
)


chi_square_file = os.path.join(
    OUTPUT_DIR,
    "Chi_Square.xlsx"
)

chi_square_results_df.to_excel(
    chi_square_file,
    index=False
)


print(
    f"Chi-square tests completed: "
    f"{len(chi_square_results_df)}"
)


# ============================================================
# 9. HYPOTHESIS TESTING
# ============================================================
#
# A two-group comparison is performed using an independent
# samples t-test when a suitable numerical variable and
# two-group categorical variable are available.
#
# Because the current survey has limited numerical variables,
# the script first checks whether such a comparison is possible.
#
# The test is included as an additional statistical analysis,
# while Chi-square is the main hypothesis test for categorical
# survey relationships.
# ============================================================

print("\nCreating hypothesis testing analysis...")


hypothesis_results = []


# ------------------------------------------------------------
# Hypothesis 1:
# Gender and Age comparison
# ------------------------------------------------------------

if (
    "Gender" in df.columns
    and "Age" in df.columns
):

    temp = df[
        [
            "Gender",
            "Age"
        ]
    ].dropna()

    gender_counts = (
        temp["Gender"]
        .value_counts()
    )

    # Use the two most common gender categories if
    # at least two categories exist.

    if len(gender_counts) >= 2:

        groups = (
            gender_counts
            .head(2)
            .index
            .tolist()
        )

        group_1 = temp[
            temp["Gender"] == groups[0]
        ]["Age"]

        group_2 = temp[
            temp["Gender"] == groups[1]
        ]["Age"]

        if (
            len(group_1) >= 2
            and len(group_2) >= 2
        ):

            statistic, p_value = ttest_ind(
                group_1,
                group_2,
                equal_var=False
            )

            hypothesis_results.append({

                "Test": "Independent Samples T-Test",

                "Variable": "Age",

                "Grouping_Variable": "Gender",

                "Group_1": groups[0],

                "Group_2": groups[1],

                "Test_Statistic": round(
                    statistic,
                    4
                ),

                "P_Value": round(
                    p_value,
                    6
                ),

                "Significance_Level": 0.05,

                "Result": (
                    "Significant Difference"
                    if p_value < 0.05
                    else
                    "No Significant Difference"
                ),

                "Null_Hypothesis": (
                    "Mean age is equal between groups"
                ),

                "Alternative_Hypothesis": (
                    "Mean age differs between groups"
                )
            })


# ------------------------------------------------------------
# Hypothesis 2:
# Daily usage and academic performance
#
# This is handled through Chi-square because both variables
# are categorical.
# ------------------------------------------------------------

if (
    "Daily_Social_Media_Time" in df.columns
    and "Academic_Performance" in df.columns
):

    temp = df[
        [
            "Daily_Social_Media_Time",
            "Academic_Performance"
        ]
    ].dropna()

    contingency = pd.crosstab(
        temp["Daily_Social_Media_Time"],
        temp["Academic_Performance"]
    )

    if (
        contingency.shape[0] >= 2
        and contingency.shape[1] >= 2
    ):

        chi2, p_value, dof, expected = (
            chi2_contingency(
                contingency
            )
        )

        hypothesis_results.append({

            "Test": "Chi-Square Test of Independence",

            "Variable": "Daily_Social_Media_Time",

            "Grouping_Variable": "Academic_Performance",

            "Group_1": "All categories",

            "Group_2": "All categories",

            "Test_Statistic": round(
                chi2,
                4
            ),

            "P_Value": round(
                p_value,
                6
            ),

            "Significance_Level": 0.05,

            "Result": (
                "Reject H0 - Significant Association"
                if p_value < 0.05
                else
                "Fail to Reject H0 - No Significant Association"
            ),

            "Null_Hypothesis": (
                "Daily social media usage and academic "
                "performance are independent"
            ),

            "Alternative_Hypothesis": (
                "Daily social media usage and academic "
                "performance are associated"
            )
        })


hypothesis_results_df = pd.DataFrame(
    hypothesis_results
)


hypothesis_file = os.path.join(
    OUTPUT_DIR,
    "Hypothesis_Testing.xlsx"
)

hypothesis_results_df.to_excel(
    hypothesis_file,
    index=False
)


print(
    f"Hypothesis tests completed: "
    f"{len(hypothesis_results_df)}"
)


# ============================================================
# 10. CREATE STATISTICAL SUMMARY
# ============================================================

summary_file = os.path.join(
    OUTPUT_DIR,
    "Statistical_Analysis_Summary.txt"
)

with open(
    summary_file,
    "w",
    encoding="utf-8"
) as file:

    file.write(
        "SURVEY DATA ANALYSIS TOOL - STATISTICAL ANALYSIS\n"
    )

    file.write(
        "=" * 60 + "\n\n"
    )

    file.write(
        f"Rows analysed: {len(df)}\n"
    )

    file.write(
        f"Columns analysed: {len(df.columns)}\n\n"
    )

    file.write(
        "Analyses performed:\n"
    )

    file.write(
        "1. Descriptive Statistics\n"
    )

    file.write(
        "2. Pearson Correlation where applicable\n"
    )

    file.write(
        "3. Spearman Correlation for ordinal variables\n"
    )

    file.write(
        "4. Covariance where applicable\n"
    )

    file.write(
        "5. Chi-Square Tests of Independence\n"
    )

    file.write(
        "6. Hypothesis Testing\n\n"
    )

    file.write(
        "Significance level used: 0.05\n"
    )


# ============================================================
# 11. FINAL OUTPUT
# ============================================================

print("\n")
print("=" * 70)
print("STATISTICAL ANALYSIS COMPLETED SUCCESSFULLY")
print("=" * 70)

print("\nOutputs saved to:")
print(OUTPUT_DIR)

print("\nFiles created:")

print(
    "  1. Descriptive_Statistics.xlsx"
)

print(
    "  2. Correlation.xlsx"
)

print(
    "  3. Covariance.xlsx"
)

print(
    "  4. Hypothesis_Testing.xlsx"
)

print(
    "  5. Chi_Square.xlsx"
)

print(
    "  6. Statistical_Analysis_Summary.txt"
)

print("\nIMPORTANT:")
print("The cleaned dataset was NOT modified.")
print("Statistical results were saved separately.")