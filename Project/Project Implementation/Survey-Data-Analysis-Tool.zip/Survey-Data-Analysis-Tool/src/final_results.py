"""
SURVEY DATA ANALYSIS TOOL
FINAL RESULTS & INSIGHTS

Purpose:
    This script combines the important findings from the completed
    Data Science pipeline into a final presentation-ready report.

Pipeline stages already completed:
    Data Inspection
    Data Integration
    Preprocessing
    EDA
    Statistical Analysis
    Feature Engineering
    Feature Selection
    Machine Learning
    Model Evaluation

IMPORTANT:
    Raw and processed datasets are NOT modified.
"""


# ============================================================
# 1. IMPORT LIBRARIES
# ============================================================

import os
import pandas as pd
import matplotlib.pyplot as plt


# ============================================================
# 2. PROJECT PATHS
# ============================================================

PROJECT_ROOT = os.path.dirname(
    os.path.dirname(os.path.abspath(__file__))
)

PROCESSED_DIR = os.path.join(
    PROJECT_ROOT,
    "data",
    "processed"
)

EDA_DIR = os.path.join(
    PROJECT_ROOT,
    "outputs",
    "02_EDA"
)

STAT_DIR = os.path.join(
    PROJECT_ROOT,
    "outputs",
    "03_Statistical_Analysis"
)

FEATURE_DIR = os.path.join(
    PROJECT_ROOT,
    "outputs",
    "04_Feature_Engineering"
)

SELECTION_DIR = os.path.join(
    PROJECT_ROOT,
    "outputs",
    "05_Feature_Selection"
)

ML_DIR = os.path.join(
    PROJECT_ROOT,
    "outputs",
    "06_Machine_Learning"
)

EVALUATION_DIR = os.path.join(
    PROJECT_ROOT,
    "outputs",
    "07_Model_Evaluation"
)

FINAL_DIR = os.path.join(
    PROJECT_ROOT,
    "outputs",
    "08_Final_Results"
)

os.makedirs(FINAL_DIR, exist_ok=True)


# ============================================================
# 3. INPUT FILE PATHS
# ============================================================

CLEANED_FILE = os.path.join(
    PROCESSED_DIR,
    "Cleaned_Data.xlsx"
)

FEATURE_FILE = os.path.join(
    PROCESSED_DIR,
    "Feature_Engineered_Data.xlsx"
)

ML_READY_FILE = os.path.join(
    PROCESSED_DIR,
    "ML_Ready_Data.xlsx"
)

MODEL_METRICS_FILE = os.path.join(
    ML_DIR,
    "Model_Metrics.xlsx"
)

PREDICTIONS_FILE = os.path.join(
    ML_DIR,
    "Test_Set_Predictions.xlsx"
)

SELECTED_FEATURES_FILE = os.path.join(
    SELECTION_DIR,
    "Selected_Features.xlsx"
)

EDA_SUMMARY_FILE = os.path.join(
    EDA_DIR,
    "EDA_Summary.txt"
)

STAT_SUMMARY_FILE = os.path.join(
    STAT_DIR,
    "Statistical_Analysis_Summary.txt"
)

FEATURE_SUMMARY_FILE = os.path.join(
    FEATURE_DIR,
    "Feature_Engineering_Summary.txt"
)

EVALUATION_SUMMARY_FILE = os.path.join(
    EVALUATION_DIR,
    "Model_Evaluation_Summary.txt"
)


# ============================================================
# 4. OUTPUT FILE PATHS
# ============================================================

FINAL_EXCEL = os.path.join(
    FINAL_DIR,
    "Final_Model_Report.xlsx"
)

FINAL_INSIGHTS_EXCEL = os.path.join(
    FINAL_DIR,
    "Final_Insights.xlsx"
)

FINAL_PREDICTIONS = os.path.join(
    FINAL_DIR,
    "Final_Predictions.xlsx"
)

FINAL_PLOT = os.path.join(
    FINAL_DIR,
    "Final_Model_Comparison.png"
)

FINAL_SUMMARY = os.path.join(
    FINAL_DIR,
    "Final_Insights.txt"
)


# ============================================================
# 5. START
# ============================================================

print("=" * 70)
print("SURVEY DATA ANALYSIS TOOL - FINAL RESULTS")
print("=" * 70)


# ============================================================
# 6. LOAD CLEANED DATA
# ============================================================

print("\nLoading cleaned survey data...")

df = pd.read_excel(CLEANED_FILE)

print("Rows    :", len(df))
print("Columns :", len(df.columns))


# ============================================================
# 7. LOAD MODEL METRICS
# ============================================================

print("\nLoading machine learning results...")

metrics_df = pd.read_excel(
    MODEL_METRICS_FILE
)

metrics_df.columns = [
    str(col).strip()
    for col in metrics_df.columns
]


# ============================================================
# 8. LOAD TEST PREDICTIONS
# ============================================================

predictions_df = pd.read_excel(
    PREDICTIONS_FILE
)


# ============================================================
# 9. LOAD SELECTED FEATURES
# ============================================================

selected_features_df = pd.read_excel(
    SELECTED_FEATURES_FILE
)


# ============================================================
# 10. IDENTIFY BEST MODEL
# ============================================================

best_row = metrics_df.loc[
    metrics_df["F1_Score"].idxmax()
]

best_model = best_row["Model"]

best_accuracy = best_row["Accuracy"]

best_precision = best_row["Precision"]

best_recall = best_row["Recall"]

best_f1 = best_row["F1_Score"]


# ============================================================
# 11. BASIC SURVEY INSIGHTS
# ============================================================

print("\nCalculating survey insights...")


# Most used platform
most_used_platform = (
    df["Most_Used_Platform"]
    .value_counts()
    .idxmax()
)

most_used_platform_count = (
    df["Most_Used_Platform"]
    .value_counts()
    .max()
)


# Daily usage distribution
usage_distribution = (
    df["Daily_Social_Media_Time"]
    .value_counts()
    .reset_index()
)

usage_distribution.columns = [
    "Daily_Social_Media_Time",
    "Response_Count"
]


# Academic performance
academic_distribution = (
    df["Academic_Performance"]
    .value_counts()
    .reset_index()
)

academic_distribution.columns = [
    "Academic_Performance",
    "Response_Count"
]


# Well-being
wellbeing_distribution = (
    df["Overall_Well_Being"]
    .value_counts()
    .reset_index()
)

wellbeing_distribution.columns = [
    "Overall_Well_Being",
    "Response_Count"
]


# Sleep quality
sleep_distribution = (
    df["Sleep_Quality"]
    .value_counts()
    .reset_index()
)

sleep_distribution.columns = [
    "Sleep_Quality",
    "Response_Count"
]


# ============================================================
# 12. TARGET DISTRIBUTION
# ============================================================

feature_df = pd.read_excel(
    FEATURE_FILE
)

target_distribution = (
    feature_df["Social_Media_Usage_Level"]
    .value_counts()
    .reset_index()
)

target_distribution.columns = [
    "Usage_Level",
    "Response_Count"
]

target_distribution["Percentage"] = (
    target_distribution["Response_Count"]
    / target_distribution["Response_Count"].sum()
    * 100
)


# ============================================================
# 13. SELECTED FEATURES
# ============================================================

# Try to identify the feature-name column automatically.

possible_feature_columns = [
    "Selected_Feature",
    "Feature",
    "Feature_Name"
]

feature_column = None

for column in possible_feature_columns:

    if column in selected_features_df.columns:
        feature_column = column
        break


if feature_column is not None:

    selected_feature_names = (
        selected_features_df[feature_column]
        .dropna()
        .astype(str)
        .tolist()
    )

else:

    # Fallback: use the first column
    selected_feature_names = (
        selected_features_df.iloc[:, 0]
        .dropna()
        .astype(str)
        .tolist()
    )


selected_features_output = pd.DataFrame({
    "Selected_Feature": selected_feature_names
})


# ============================================================
# 14. MODEL COMPARISON
# ============================================================

model_comparison = metrics_df.copy()

model_comparison["Accuracy_Percent"] = (
    model_comparison["Accuracy"] * 100
)

model_comparison["Precision_Percent"] = (
    model_comparison["Precision"] * 100
)

model_comparison["Recall_Percent"] = (
    model_comparison["Recall"] * 100
)

model_comparison["F1_Score_Percent"] = (
    model_comparison["F1_Score"] * 100
)

model_comparison = model_comparison.sort_values(
    by="F1_Score",
    ascending=False
)

model_comparison["Rank"] = range(
    1,
    len(model_comparison) + 1
)


# ============================================================
# 15. CREATE FINAL MODEL COMPARISON CHART
# ============================================================

print("\nCreating final model comparison chart...")

plt.figure(figsize=(11, 6))

plt.bar(
    model_comparison["Model"],
    model_comparison["F1_Score_Percent"]
)

plt.xlabel("Machine Learning Model")

plt.ylabel("F1-Score (%)")

plt.title(
    "Final Machine Learning Model Comparison"
)

plt.xticks(
    rotation=20
)

plt.tight_layout()

plt.savefig(
    FINAL_PLOT,
    dpi=300,
    bbox_inches="tight"
)

plt.close()


# ============================================================
# 16. CREATE FINAL MODEL REPORT
# ============================================================

print("\nCreating final model report...")

best_model_table = pd.DataFrame({
    "Metric": [
        "Best Model",
        "Accuracy",
        "Precision",
        "Recall",
        "F1-Score"
    ],
    "Value": [
        best_model,
        f"{best_accuracy * 100:.2f}%",
        f"{best_precision * 100:.2f}%",
        f"{best_recall * 100:.2f}%",
        f"{best_f1 * 100:.2f}%"
    ]
})


with pd.ExcelWriter(
    FINAL_EXCEL,
    engine="openpyxl"
) as writer:

    model_comparison.to_excel(
        writer,
        sheet_name="Model_Comparison",
        index=False
    )

    best_model_table.to_excel(
        writer,
        sheet_name="Best_Model",
        index=False
    )

    target_distribution.to_excel(
        writer,
        sheet_name="Usage_Level_Distribution",
        index=False
    )

    usage_distribution.to_excel(
        writer,
        sheet_name="Daily_Usage",
        index=False
    )

    academic_distribution.to_excel(
        writer,
        sheet_name="Academic_Performance",
        index=False
    )

    wellbeing_distribution.to_excel(
        writer,
        sheet_name="Well_Being",
        index=False
    )

    sleep_distribution.to_excel(
        writer,
        sheet_name="Sleep_Quality",
        index=False
    )

    selected_features_output.to_excel(
        writer,
        sheet_name="Selected_Features",
        index=False
    )


# ============================================================
# 17. CREATE FINAL INSIGHTS WORKBOOK
# ============================================================

print("\nCreating final insights workbook...")

insights = [
    [
        "Dataset",
        "Primary Google Survey dataset"
    ],
    [
        "Total Survey Responses",
        len(df)
    ],
    [
        "Most Used Platform",
        most_used_platform
    ],
    [
        "Most Used Platform Response Count",
        most_used_platform_count
    ],
    [
        "Best ML Model",
        best_model
    ],
    [
        "Best Model Accuracy",
        f"{best_accuracy * 100:.2f}%"
    ],
    [
        "Best Model Precision",
        f"{best_precision * 100:.2f}%"
    ],
    [
        "Best Model Recall",
        f"{best_recall * 100:.2f}%"
    ],
    [
        "Best Model F1-Score",
        f"{best_f1 * 100:.2f}%"
    ],
    [
        "Number of Selected Features",
        len(selected_feature_names)
    ]
]

insights_df = pd.DataFrame(
    insights,
    columns=[
        "Insight",
        "Result"
    ]
)


with pd.ExcelWriter(
    FINAL_INSIGHTS_EXCEL,
    engine="openpyxl"
) as writer:

    insights_df.to_excel(
        writer,
        sheet_name="Key_Insights",
        index=False
    )

    target_distribution.to_excel(
        writer,
        sheet_name="Usage_Level",
        index=False
    )

    model_comparison.to_excel(
        writer,
        sheet_name="Model_Performance",
        index=False
    )

    selected_features_output.to_excel(
        writer,
        sheet_name="Selected_Features",
        index=False
    )


# ============================================================
# 18. SAVE FINAL PREDICTIONS
# ============================================================

print("\nSaving final predictions...")

predictions_df.to_excel(
    FINAL_PREDICTIONS,
    index=False
)


# ============================================================
# 19. CREATE TEXT INSIGHTS
# ============================================================

summary = f"""
SURVEY DATA ANALYSIS TOOL
FINAL RESULTS AND INSIGHTS
======================================================================

DATASET
-------
Primary dataset:
Google Survey

Total survey responses analysed:
{len(df)}

The project also uses two Kaggle datasets as secondary
contextual/reference datasets.

USAGE LEVEL DISTRIBUTION
------------------------
"""

for _, row in target_distribution.iterrows():

    summary += (
        f"{row['Usage_Level']}: "
        f"{int(row['Response_Count'])} responses "
        f"({row['Percentage']:.2f}%)\n"
    )


summary += f"""
MAIN SURVEY INSIGHTS
--------------------
Most used platform:
{most_used_platform}

Responses using the most common platform:
{most_used_platform_count}

MACHINE LEARNING RESULTS
------------------------
Best model:
{best_model}

Accuracy:
{best_accuracy * 100:.2f}%

Precision:
{best_precision * 100:.2f}%

Recall:
{best_recall * 100:.2f}%

F1-Score:
{best_f1 * 100:.2f}%

MODEL RANKING
-------------
"""

for _, row in model_comparison.iterrows():

    summary += (
        f"{int(row['Rank'])}. {row['Model']} - "
        f"Accuracy: {row['Accuracy_Percent']:.2f}%, "
        f"F1-Score: {row['F1_Score_Percent']:.2f}%\n"
    )


summary += f"""
FEATURE SELECTION
-----------------
Number of selected features:
{len(selected_feature_names)}

Selected features:
"""

for feature in selected_feature_names:

    summary += f"- {feature}\n"


summary += """
FINAL INTERPRETATION
--------------------
The project successfully completed an end-to-end Data Science
workflow for analysing student social media usage behaviour.

The workflow included:
Data Inspection
Data Integration
Data Preprocessing
Exploratory Data Analysis
Statistical Analysis
Feature Engineering
Feature Selection
Machine Learning
Model Evaluation

Logistic Regression achieved the highest weighted F1-score
among the five evaluated classification models and was therefore
selected as the final model.

The final results should be interpreted as findings from the
available survey dataset. The survey dataset contains simulated
responses in addition to the original submitted response, so
these results should not be presented as population-level
student statistics.

The final outputs are prepared for use in the Streamlit
dashboard.

======================================================================
"""


with open(
    FINAL_SUMMARY,
    "w",
    encoding="utf-8"
) as file:

    file.write(summary)


# ============================================================
# 20. FINAL TERMINAL OUTPUT
# ============================================================

print("\n")
print("=" * 70)
print("FINAL RESULTS CREATED SUCCESSFULLY")
print("=" * 70)

print("\nTotal survey responses analysed:", len(df))

print(
    "\nMost Used Platform:",
    most_used_platform
)

print(
    "Best ML Model:",
    best_model
)

print(
    f"Best Accuracy: {best_accuracy * 100:.2f}%"
)

print(
    f"Best F1-Score: {best_f1 * 100:.2f}%"
)

print("\nFinal model report saved to:")
print(FINAL_EXCEL)

print("\nFinal insights saved to:")
print(FINAL_INSIGHTS_EXCEL)

print("\nFinal predictions saved to:")
print(FINAL_PREDICTIONS)

print("\nFinal model comparison chart saved to:")
print(FINAL_PLOT)

print("\nFinal text insights saved to:")
print(FINAL_SUMMARY)

print("\nIMPORTANT:")
print("Previous datasets were NOT modified.")
print("ML results were consolidated into final project outputs.")
print("These outputs will be used for the Streamlit dashboard.")

print("=" * 70)