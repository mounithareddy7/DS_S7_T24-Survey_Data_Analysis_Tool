"""
SURVEY DATA ANALYSIS TOOL
MODEL EVALUATION & COMPARISON

Purpose:
    This script performs the final evaluation of the five machine
    learning models used in the project.

Models evaluated:
    1. Logistic Regression
    2. Decision Tree
    3. Random Forest
    4. KNN
    5. SVM

The script:
    - Reads the ML model metrics
    - Compares all five models
    - Identifies the best model
    - Creates a comparison chart
    - Creates a presentation-ready Excel report
    - Generates a text summary

IMPORTANT:
    This stage does NOT modify the ML-ready dataset.
"""


# ============================================================
# 1. IMPORT REQUIRED LIBRARIES
# ============================================================

import os
import pandas as pd
import matplotlib.pyplot as plt


# ============================================================
# 2. DEFINE PROJECT PATHS
# ============================================================

# Project root directory
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# ML output folder
ML_OUTPUT_DIR = os.path.join(
    PROJECT_ROOT,
    "outputs",
    "06_Machine_Learning"
)

# Final model evaluation folder
EVALUATION_DIR = os.path.join(
    PROJECT_ROOT,
    "outputs",
    "07_Model_Evaluation"
)

# Create evaluation folder if it does not already exist
os.makedirs(EVALUATION_DIR, exist_ok=True)


# ============================================================
# 3. DEFINE INPUT AND OUTPUT FILES
# ============================================================

# Input created during Machine Learning stage
METRICS_FILE = os.path.join(
    ML_OUTPUT_DIR,
    "Model_Metrics.xlsx"
)

# Output Excel report
EVALUATION_EXCEL = os.path.join(
    EVALUATION_DIR,
    "Model_Evaluation.xlsx"
)

# Output chart
COMPARISON_PLOT = os.path.join(
    EVALUATION_DIR,
    "Model_Comparison.png"
)

# Output text summary
SUMMARY_FILE = os.path.join(
    EVALUATION_DIR,
    "Model_Evaluation_Summary.txt"
)


# ============================================================
# 4. DISPLAY PROJECT INFORMATION
# ============================================================

print("=" * 70)
print("SURVEY DATA ANALYSIS TOOL - MODEL EVALUATION")
print("=" * 70)

print("\nLoading machine learning results...")


# ============================================================
# 5. CHECK WHETHER ML OUTPUT EXISTS
# ============================================================

if not os.path.exists(METRICS_FILE):

    print("\nERROR:")
    print("Model_Metrics.xlsx was not found.")

    print("\nExpected location:")
    print(METRICS_FILE)

    print("\nPlease run:")
    print("python src\\machine_learning.py")

    raise FileNotFoundError(METRICS_FILE)


# ============================================================
# 6. LOAD MODEL METRICS
# ============================================================

metrics_df = pd.read_excel(METRICS_FILE)

print("\nModel metrics loaded successfully.")

print("\nAvailable model results:")
print(metrics_df.to_string(index=False))


# ============================================================
# 7. STANDARDIZE COLUMN NAMES
# ============================================================

metrics_df.columns = [
    str(column).strip()
    for column in metrics_df.columns
]


# ============================================================
# 8. IDENTIFY THE BEST MODEL
# ============================================================

# The ML stage selected the best model using weighted F1-score.
best_model_row = metrics_df.loc[
    metrics_df["F1_Score"].idxmax()
]

best_model = best_model_row["Model"]

best_accuracy = best_model_row["Accuracy"]

best_precision = best_model_row["Precision"]

best_recall = best_model_row["Recall"]

best_f1 = best_model_row["F1_Score"]


# ============================================================
# 9. CREATE MODEL RANKING
# ============================================================

ranking_df = metrics_df.copy()

# Rank models according to F1-score.
ranking_df["F1_Rank"] = (
    ranking_df["F1_Score"]
    .rank(
        ascending=False,
        method="min"
    )
    .astype(int)
)

# Sort from best to worst
ranking_df = ranking_df.sort_values(
    by="F1_Score",
    ascending=False
)

# Reset index
ranking_df = ranking_df.reset_index(drop=True)


# ============================================================
# 10. CREATE INTERPRETATION TABLE
# ============================================================

interpretation_rows = []

for _, row in ranking_df.iterrows():

    model_name = row["Model"]

    accuracy = row["Accuracy"]
    precision = row["Precision"]
    recall = row["Recall"]
    f1 = row["F1_Score"]

    interpretation_rows.append({
        "Model": model_name,
        "Accuracy_Percent": round(accuracy * 100, 2),
        "Precision_Percent": round(precision * 100, 2),
        "Recall_Percent": round(recall * 100, 2),
        "F1_Score_Percent": round(f1 * 100, 2)
    })

interpretation_df = pd.DataFrame(
    interpretation_rows
)


# ============================================================
# 11. CREATE MODEL COMPARISON CHART
# ============================================================

print("\nCreating model comparison chart...")

models = ranking_df["Model"]

accuracy_values = ranking_df["Accuracy"] * 100
f1_values = ranking_df["F1_Score"] * 100

x = range(len(models))

plt.figure(figsize=(11, 6))

width = 0.35

plt.bar(
    [i - width / 2 for i in x],
    accuracy_values,
    width=width,
    label="Accuracy (%)"
)

plt.bar(
    [i + width / 2 for i in x],
    f1_values,
    width=width,
    label="F1-Score (%)"
)

plt.xticks(
    list(x),
    models,
    rotation=20
)

plt.ylabel("Score (%)")

plt.xlabel("Machine Learning Model")

plt.title(
    "Machine Learning Model Comparison"
)

plt.legend()

plt.tight_layout()

plt.savefig(
    COMPARISON_PLOT,
    dpi=300,
    bbox_inches="tight"
)

plt.close()

print("Model comparison chart saved.")


# ============================================================
# 12. CREATE FINAL EVALUATION EXCEL WORKBOOK
# ============================================================

print("\nCreating evaluation Excel workbook...")

with pd.ExcelWriter(
    EVALUATION_EXCEL,
    engine="openpyxl"
) as writer:

    # Sheet 1:
    # Original metrics
    metrics_df.to_excel(
        writer,
        sheet_name="Model_Metrics",
        index=False
    )

    # Sheet 2:
    # Models ranked by F1-score
    ranking_df.to_excel(
        writer,
        sheet_name="Model_Ranking",
        index=False
    )

    # Sheet 3:
    # Percentage interpretation
    interpretation_df.to_excel(
        writer,
        sheet_name="Performance_Percentage",
        index=False
    )

    # Sheet 4:
    # Best model information
    best_model_df = pd.DataFrame({
        "Metric": [
            "Best Model",
            "Accuracy",
            "Precision",
            "Recall",
            "F1-Score"
        ],
        "Value": [
            best_model,
            round(best_accuracy, 4),
            round(best_precision, 4),
            round(best_recall, 4),
            round(best_f1, 4)
        ],
        "Percentage": [
            "",
            f"{best_accuracy * 100:.2f}%",
            f"{best_precision * 100:.2f}%",
            f"{best_recall * 100:.2f}%",
            f"{best_f1 * 100:.2f}%"
        ]
    })

    best_model_df.to_excel(
        writer,
        sheet_name="Best_Model",
        index=False
    )


# ============================================================
# 13. CREATE TEXT SUMMARY
# ============================================================

summary_text = f"""
SURVEY DATA ANALYSIS TOOL
MODEL EVALUATION SUMMARY
============================================================

PURPOSE
-------
This stage compares the five machine learning models
developed for classifying students into:

    Low
    Moderate
    Heavy

social media usage categories.

MODELS EVALUATED
----------------
1. Logistic Regression
2. Decision Tree
3. Random Forest
4. KNN
5. SVM

MODEL RANKING
-------------

"""

for position, (_, row) in enumerate(
    ranking_df.iterrows(),
    start=1
):

    summary_text += (
        f"{position}. {row['Model']}\n"
        f"   Accuracy : {row['Accuracy'] * 100:.2f}%\n"
        f"   Precision: {row['Precision'] * 100:.2f}%\n"
        f"   Recall   : {row['Recall'] * 100:.2f}%\n"
        f"   F1-Score : {row['F1_Score'] * 100:.2f}%\n\n"
    )


summary_text += f"""
BEST MODEL
----------
Model      : {best_model}
Accuracy   : {best_accuracy * 100:.2f}%
Precision  : {best_precision * 100:.2f}%
Recall     : {best_recall * 100:.2f}%
F1-Score   : {best_f1 * 100:.2f}%

MODEL SELECTION CRITERION
-------------------------
The best model was selected based on the highest weighted
F1-score because F1-score provides a balance between
precision and recall.

INTERPRETATION
--------------
The results show that Logistic Regression achieved the
highest weighted F1-score among the five tested models.

Therefore, Logistic Regression is selected as the final
classification model for the project.

IMPORTANT
---------
The model results are reported as obtained from the test
dataset. No artificial improvement of model performance
was performed.

The evaluation outputs are saved separately from the
ML-ready dataset.

============================================================
"""


with open(
    SUMMARY_FILE,
    "w",
    encoding="utf-8"
) as file:

    file.write(summary_text)


# ============================================================
# 14. FINAL OUTPUT
# ============================================================

print("\n")
print("=" * 70)
print("MODEL EVALUATION COMPLETED SUCCESSFULLY")
print("=" * 70)

print("\nModel ranking:")

print(
    ranking_df[
        [
            "Model",
            "Accuracy",
            "Precision",
            "Recall",
            "F1_Score"
        ]
    ].to_string(index=False)
)

print("\nBEST MODEL:", best_model)

print(
    f"Best Accuracy : {best_accuracy * 100:.2f}%"
)

print(
    f"Best F1-Score : {best_f1 * 100:.2f}%"
)

print("\nEvaluation Excel saved to:")
print(EVALUATION_EXCEL)

print("\nModel comparison chart saved to:")
print(COMPARISON_PLOT)

print("\nEvaluation summary saved to:")
print(SUMMARY_FILE)

print("\nIMPORTANT:")
print("The ML-ready dataset was NOT modified.")
print("The machine learning results were evaluated separately.")
print("The best model was selected using weighted F1-score.")

print("=" * 70)