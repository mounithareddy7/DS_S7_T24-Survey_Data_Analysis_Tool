# ================================================================
# SURVEY DATA ANALYSIS TOOL
# STEP 06 - FEATURE SELECTION
# ================================================================
#
# Purpose:
# Select the most useful predictor variables before Machine Learning.
#
# Input:
# data/processed/Feature_Engineered_Data.xlsx
#
# Outputs:
# data/processed/ML_Ready_Data.xlsx
# outputs/05_Feature_Selection/Feature_Importance.xlsx
# outputs/05_Feature_Selection/Selected_Features.xlsx
# outputs/05_Feature_Selection/Feature_Selection_Summary.txt
#
# IMPORTANT:
# The target variable is:
#     Social_Media_Usage_Level
#
# Daily_Social_Media_Time is excluded because it directly defines
# the target Low / Moderate / Heavy usage category.
# Including it would cause target leakage.
# ================================================================

import os
import pandas as pd
import numpy as np

from sklearn.preprocessing import LabelEncoder
from sklearn.feature_selection import mutual_info_classif
from sklearn.ensemble import RandomForestClassifier


# ================================================================
# 1. DEFINE INPUT AND OUTPUT PATHS
# ================================================================

INPUT_FILE = r"data\processed\Feature_Engineered_Data.xlsx"

OUTPUT_DIR = r"outputs\05_Feature_Selection"

ML_READY_FILE = r"data\processed\ML_Ready_Data.xlsx"

FEATURE_IMPORTANCE_FILE = os.path.join(
    OUTPUT_DIR,
    "Feature_Importance.xlsx"
)

SELECTED_FEATURES_FILE = os.path.join(
    OUTPUT_DIR,
    "Selected_Features.xlsx"
)

SUMMARY_FILE = os.path.join(
    OUTPUT_DIR,
    "Feature_Selection_Summary.txt"
)


# Create output folder if it does not exist
os.makedirs(OUTPUT_DIR, exist_ok=True)


print("=" * 70)
print("SURVEY DATA ANALYSIS TOOL - FEATURE SELECTION")
print("=" * 70)


# ================================================================
# 2. LOAD FEATURE-ENGINEERED DATA
# ================================================================

print("\nLoading feature-engineered dataset...")

df = pd.read_excel(INPUT_FILE)

print(f"Rows    : {df.shape[0]}")
print(f"Columns : {df.shape[1]}")


# ================================================================
# 3. DEFINE TARGET VARIABLE
# ================================================================

TARGET = "Social_Media_Usage_Level"

if TARGET not in df.columns:
    raise ValueError(
        f"Target column '{TARGET}' was not found in the dataset."
    )

print(f"\nTarget variable: {TARGET}")


# ================================================================
# 4. SEPARATE TARGET FROM PREDICTOR VARIABLES
# ================================================================

y = df[TARGET].copy()

X = df.drop(columns=[TARGET]).copy()

print("\nTarget distribution:")

print(
    y.value_counts()
)


# ================================================================
# 5. REMOVE TARGET LEAKAGE
# ================================================================
#
# Daily_Social_Media_Time directly determines:
#
# Less than 1 hour / 1-2 hours -> Low
# 2-3 hours / 3-5 hours       -> Moderate
# More than 5 hours            -> Heavy
#
# Therefore this column cannot be used as a predictor.
#
# We also remove Timestamp because it is not a meaningful
# behavioural predictor for the classification model.
#
# Name has already been removed during preprocessing.
# ================================================================

LEAKAGE_COLUMNS = [
    "Daily_Social_Media_Time",
    "Timestamp"
]

removed_columns = []

for column in LEAKAGE_COLUMNS:

    if column in X.columns:

        X = X.drop(columns=[column])

        removed_columns.append(column)


print("\nLeakage / non-predictive columns removed:")

if removed_columns:

    for column in removed_columns:
        print(f"  - {column}")

else:

    print("  None")


# ================================================================
# 6. REMOVE CONSTANT / EMPTY COLUMNS
# ================================================================

constant_columns = []

for column in X.columns:

    if X[column].nunique(dropna=False) <= 1:

        constant_columns.append(column)


if constant_columns:

    X = X.drop(columns=constant_columns)

    print("\nConstant columns removed:")

    for column in constant_columns:
        print(f"  - {column}")

else:

    print("\nNo constant columns found.")


# ================================================================
# 7. HANDLE MISSING VALUES
# ================================================================

print("\nChecking missing values...")

missing_before = int(X.isnull().sum().sum())

print(
    f"Missing values before handling: {missing_before}"
)


# Numerical columns -> median
numeric_columns = X.select_dtypes(
    include=["int64", "float64", "int32", "float32"]
).columns.tolist()


for column in numeric_columns:

    if X[column].isnull().any():

        X[column] = X[column].fillna(
            X[column].median()
        )


# Text/categorical columns -> mode
categorical_columns = X.select_dtypes(
    include=["object", "string", "category"]
).columns.tolist()


for column in categorical_columns:

    if X[column].isnull().any():

        mode_value = X[column].mode()

        if len(mode_value) > 0:

            X[column] = X[column].fillna(
                mode_value.iloc[0]
            )

        else:

            X[column] = X[column].fillna("Unknown")


missing_after = int(X.isnull().sum().sum())

print(
    f"Missing values after handling : {missing_after}"
)


# ================================================================
# 8. ENCODE TARGET VARIABLE
# ================================================================

print("\nEncoding target variable...")

target_encoder = LabelEncoder()

y_encoded = target_encoder.fit_transform(y.astype(str))

target_mapping = {
    int(index): label
    for index, label in enumerate(target_encoder.classes_)
}

print("Target encoding:")

for encoded_value, label in target_mapping.items():

    print(
        f"  {encoded_value} = {label}"
    )


# ================================================================
# 9. ENCODE CATEGORICAL PREDICTORS
# ================================================================
#
# Machine Learning feature-selection algorithms require
# numerical input.
#
# We use Label Encoding for categorical predictors.
#
# The encoded dataset is only used internally for feature
# selection. The final ML-ready dataset will retain the
# original predictor columns where possible.
# ================================================================

print("\nEncoding categorical predictor variables...")

X_encoded = X.copy()

feature_encoders = {}

for column in X_encoded.columns:

    if (
        X_encoded[column].dtype == "object"
        or str(X_encoded[column].dtype) == "string"
        or str(X_encoded[column].dtype) == "category"
    ):

        encoder = LabelEncoder()

        X_encoded[column] = encoder.fit_transform(
            X_encoded[column].astype(str)
        )

        feature_encoders[column] = encoder


print(
    f"Categorical columns encoded: {len(feature_encoders)}"
)


# ================================================================
# 10. CONVERT ALL DATA TO NUMERIC
# ================================================================

X_encoded = X_encoded.apply(
    pd.to_numeric,
    errors="coerce"
)

X_encoded = X_encoded.fillna(0)


# ================================================================
# 11. MUTUAL INFORMATION
# ================================================================
#
# Mutual Information measures how much information a feature
# provides about the target variable.
#
# Higher value = stronger relationship with target.
# ================================================================

print("\nCalculating Mutual Information scores...")

mi_scores = mutual_info_classif(
    X_encoded,
    y_encoded,
    random_state=42
)

mi_df = pd.DataFrame({
    "Feature": X_encoded.columns,
    "Mutual_Information": mi_scores
})

mi_df = mi_df.sort_values(
    by="Mutual_Information",
    ascending=False
).reset_index(drop=True)


# ================================================================
# 12. RANDOM FOREST FEATURE IMPORTANCE
# ================================================================
#
# Random Forest can estimate how important each predictor is
# for classification.
# ================================================================

print("\nCalculating Random Forest feature importance...")

rf_model = RandomForestClassifier(
    n_estimators=200,
    random_state=42,
    class_weight="balanced",
    n_jobs=-1
)

rf_model.fit(
    X_encoded,
    y_encoded
)

rf_df = pd.DataFrame({
    "Feature": X_encoded.columns,
    "Random_Forest_Importance": rf_model.feature_importances_
})

rf_df = rf_df.sort_values(
    by="Random_Forest_Importance",
    ascending=False
).reset_index(drop=True)


# ================================================================
# 13. COMBINE FEATURE SCORES
# ================================================================

print("\nCombining feature-selection scores...")

importance_df = pd.merge(
    mi_df,
    rf_df,
    on="Feature",
    how="outer"
)

importance_df["Mutual_Information"] = (
    importance_df["Mutual_Information"].fillna(0)
)

importance_df["Random_Forest_Importance"] = (
    importance_df["Random_Forest_Importance"].fillna(0)
)


# ================================================================
# 14. NORMALIZE BOTH SCORES
# ================================================================

def normalize(series):

    minimum = series.min()
    maximum = series.max()

    if maximum == minimum:

        return pd.Series(
            np.zeros(len(series)),
            index=series.index
        )

    return (
        (series - minimum)
        / (maximum - minimum)
    )


importance_df["MI_Normalized"] = normalize(
    importance_df["Mutual_Information"]
)

importance_df["RF_Normalized"] = normalize(
    importance_df["Random_Forest_Importance"]
)


# ================================================================
# 15. CREATE COMBINED FEATURE SCORE
# ================================================================
#
# Both methods are given equal importance.
#
# Combined Score =
# 50% Mutual Information
# + 50% Random Forest Importance
# ================================================================

importance_df["Combined_Score"] = (
    0.5 * importance_df["MI_Normalized"]
    +
    0.5 * importance_df["RF_Normalized"]
)


importance_df = importance_df.sort_values(
    by="Combined_Score",
    ascending=False
).reset_index(drop=True)


importance_df["Rank"] = (
    importance_df.index + 1
)


# ================================================================
# 16. SELECT TOP FEATURES
# ================================================================
#
# We select up to 12 strong predictors.
#
# The final number is also limited by the number of available
# predictors.
# ================================================================

NUMBER_OF_FEATURES = min(
    12,
    len(importance_df)
)

selected_features = (
    importance_df
    .head(NUMBER_OF_FEATURES)
    ["Feature"]
    .tolist()
)


print(
    f"\nNumber of selected features: "
    f"{len(selected_features)}"
)

print("\nSelected features:")

for index, feature in enumerate(
    selected_features,
    start=1
):

    print(
        f"  {index}. {feature}"
    )


# ================================================================
# 17. CREATE ML-READY DATASET
# ================================================================
#
# Keep the selected original features plus the target.
#
# This dataset will be passed to the Machine Learning stage.
# ================================================================

ml_ready_df = X[
    selected_features
].copy()

ml_ready_df[TARGET] = y.values


# ================================================================
# 18. SAVE ML-READY DATASET
# ================================================================

print("\nSaving ML-ready dataset...")

ml_ready_df.to_excel(
    ML_READY_FILE,
    index=False
)


# ================================================================
# 19. CREATE FEATURE SELECTION OUTPUT TABLE
# ================================================================

selected_features_df = importance_df[
    importance_df["Feature"].isin(
        selected_features
    )
].copy()


selected_features_df = selected_features_df.sort_values(
    by="Combined_Score",
    ascending=False
).reset_index(drop=True)


selected_features_df["Selected"] = "Yes"


# ================================================================
# 20. SAVE FEATURE IMPORTANCE REPORT
# ================================================================

print("Saving feature importance report...")

with pd.ExcelWriter(
    FEATURE_IMPORTANCE_FILE,
    engine="openpyxl"
) as writer:

    importance_df.to_excel(
        writer,
        sheet_name="All_Features",
        index=False
    )

    mi_df.to_excel(
        writer,
        sheet_name="Mutual_Information",
        index=False
    )

    rf_df.to_excel(
        writer,
        sheet_name="Random_Forest",
        index=False
    )

    selected_features_df.to_excel(
        writer,
        sheet_name="Selected_Features",
        index=False
    )


# ================================================================
# 21. SAVE SELECTED FEATURES REPORT
# ================================================================

print("Saving selected feature report...")

with pd.ExcelWriter(
    SELECTED_FEATURES_FILE,
    engine="openpyxl"
) as writer:

    selected_features_df.to_excel(
        writer,
        sheet_name="Selected_Features",
        index=False
    )

    pd.DataFrame({
        "Selected_Feature": selected_features
    }).to_excel(
        writer,
        sheet_name="Feature_List",
        index=False
    )

    pd.DataFrame({
        "Target": [TARGET],
        "Target_Definition": [
            "Low / Moderate / Heavy social media usage"
        ],
        "Number_of_Selected_Features": [
            len(selected_features)
        ],
        "Leakage_Removed": [
            "Daily_Social_Media_Time"
        ]
    }).to_excel(
        writer,
        sheet_name="Selection_Summary",
        index=False
    )


# ================================================================
# 22. CREATE TEXT SUMMARY
# ================================================================

with open(
    SUMMARY_FILE,
    "w",
    encoding="utf-8"
) as file:

    file.write(
        "SURVEY DATA ANALYSIS TOOL - FEATURE SELECTION SUMMARY\n"
    )

    file.write(
        "=" * 60 + "\n\n"
    )

    file.write(
        f"Input rows: {df.shape[0]}\n"
    )

    file.write(
        f"Input columns: {df.shape[1]}\n\n"
    )

    file.write(
        f"Target variable: {TARGET}\n\n"
    )

    file.write(
        "Target distribution:\n"
    )

    for value, count in y.value_counts().items():

        file.write(
            f"  {value}: {count}\n"
        )

    file.write("\n")

    file.write(
        "Columns removed to prevent leakage/non-predictive input:\n"
    )

    for column in removed_columns:

        file.write(
            f"  - {column}\n"
        )

    file.write("\n")

    file.write(
        "Selected features:\n"
    )

    for index, feature in enumerate(
        selected_features,
        start=1
    ):

        file.write(
            f"  {index}. {feature}\n"
        )

    file.write("\n")

    file.write(
        "Feature selection methods:\n"
    )

    file.write(
        "  1. Mutual Information\n"
    )

    file.write(
        "  2. Random Forest Feature Importance\n"
    )

    file.write(
        "  3. Combined normalized score\n"
    )

    file.write("\n")

    file.write(
        "Important methodological note:\n"
    )

    file.write(
        "Daily_Social_Media_Time was excluded because it directly "
        "defines the Low / Moderate / Heavy target variable. "
        "Including it would cause target leakage.\n"
    )


# ================================================================
# 23. FINAL OUTPUT
# ================================================================

print("\n")
print("=" * 70)
print("FEATURE SELECTION COMPLETED SUCCESSFULLY")
print("=" * 70)

print("\nOriginal feature-engineered dataset:")
print(f"  Rows    : {df.shape[0]}")
print(f"  Columns : {df.shape[1]}")

print("\nFeatures available for selection:")
print(f"  {X.shape[1]}")

print("\nSelected features:")
print(f"  {len(selected_features)}")

print("\nSelected feature list:")

for index, feature in enumerate(
    selected_features,
    start=1
):

    print(
        f"  {index}. {feature}"
    )

print("\nML-ready dataset saved to:")
print(
    os.path.abspath(ML_READY_FILE)
)

print("\nFeature importance report saved to:")
print(
    os.path.abspath(FEATURE_IMPORTANCE_FILE)
)

print("\nSelected features report saved to:")
print(
    os.path.abspath(SELECTED_FEATURES_FILE)
)

print("\nFeature selection summary saved to:")
print(
    os.path.abspath(SUMMARY_FILE)
)

print("\nIMPORTANT:")
print("The feature-engineered dataset was NOT modified.")
print("Target leakage was removed before feature selection.")
print("The ML-ready dataset will be used for Machine Learning.")

print("=" * 70)